﻿"""素材管理路由 - 兼容本地存储和COS"""
import os
import uuid
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy import select

from src.zhitan.models.database import async_session, Material
from src.zhitan.routers.auth import get_current_merchant
from src.zhitan.config import MAX_UPLOAD_MB, CHUNK_SIZE

router = APIRouter()

UPLOAD_DIR = "static/uploads/materials"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# 支持的格式
VIDEO_EXTS = {"mp4", "mov", "avi", "mkv", "webm"}
IMAGE_EXTS = {"jpg", "jpeg", "png", "webp", "heic"}


@router.get("")
async def list_materials(
    store_id: Optional[int] = None,
    merchant: dict = Depends(get_current_merchant),
):
    """素材列表"""
    async with async_session() as db:
        from src.zhitan.models.database import Store
        query = select(Material).join(Store).where(Store.merchant_id == merchant["merchant_id"])
        if store_id:
            query = query.where(Material.store_id == store_id)
        query = query.order_by(Material.uploaded_at.desc())

        r = await db.execute(query)
        materials = r.scalars().all()
        return {
            "status": "success",
            "materials": [
                {
                    "id": m.id,
                    "store_id": m.store_id,
                    "file_url": m.file_url,
                    "file_type": m.file_type,
                    "duration": m.duration,
                    "file_size": m.file_size,
                    "width": m.width,
                    "height": m.height,
                    "thumbnail_url": m.thumbnail_url,
                    "used_count": m.used_count,
                    "uploaded_at": m.uploaded_at.isoformat() if m.uploaded_at else None,
                }
                for m in materials
            ],
        }


@router.post("/upload")
async def upload_material(
    store_id: int = Form(...),
    file: UploadFile = File(...),
    merchant: dict = Depends(get_current_merchant),
):
    """上传素材文件（支持大文件流式写入）"""
    # 校验门店归属
    async with async_session() as db:
        from src.zhitan.models.database import Store
        r = await db.execute(
            select(Store).where(Store.id == store_id, Store.merchant_id == merchant["merchant_id"])
        )
        if not r.scalar_one_or_none():
            raise HTTPException(403, "门店不存在或无权操作")

    # 判断文件类型
    ext = file.filename.rsplit(".", 1)[-1].lower() if file.filename else ""
    if ext in VIDEO_EXTS:
        file_type = 1
    elif ext in IMAGE_EXTS:
        file_type = 2
    else:
        raise HTTPException(400, f"不支持的格式: .{ext}，请上传视频(mp4/mov)或图片(jpg/png/webp)")

    # 检查文件大小（先尝试读取 Content-Length 头）
    max_bytes = MAX_UPLOAD_MB * 1024 * 1024
    content_length = file.headers.get("content-length")
    if content_length and int(content_length) > max_bytes:
        raise HTTPException(413, f"文件过大（最大 {MAX_UPLOAD_MB}MB）")

    # 保存到本地（流式写入，支持大文件）
    filename = f"{uuid.uuid4().hex}.{ext}"
    filepath = os.path.join(UPLOAD_DIR, filename)
    total_size = 0

    with open(filepath, "wb", buffering=CHUNK_SIZE) as f:
        while True:
            chunk = await file.read(CHUNK_SIZE)
            if not chunk:
                break
            total_size += len(chunk)
            if total_size > max_bytes:
                f.close()
                os.remove(filepath)
                raise HTTPException(413, f"文件过大（最大 {MAX_UPLOAD_MB}MB，已阻止）")
            f.write(chunk)

    file_url = f"/static/uploads/materials/{filename}"

    async with async_session() as db:
        material = Material(
            store_id=store_id,
            file_url=file_url,
            file_type=file_type,
            file_size=total_size,
        )
        db.add(material)
        await db.commit()
        await db.refresh(material)
        return {
            "status": "success",
            "material_id": material.id,
            "file_url": file_url,
            "file_size": total_size,
            "file_type": "video" if file_type == 1 else "image",
        }


@router.get("/upload-url")
async def get_upload_url(
    store_id: int,
    filename: str,
    merchant: dict = Depends(get_current_merchant),
):
    """获取COS预签名上传URL（MVP简化：返回本地上传端点）"""
    return {
        "status": "success",
        "upload_url": f"/api/v1/materials/upload",
        "fields": {"store_id": store_id},
        "message": "请使用 POST /api/v1/materials/upload 上传，携带 store_id 和 file",
    }


@router.delete("/{material_id}")
async def delete_material(material_id: int, merchant: dict = Depends(get_current_merchant)):
    """删除素材"""
    async with async_session() as db:
        from src.zhitan.models.database import Store
        r = await db.execute(
            select(Material).join(Store).where(
                Material.id == material_id,
                Store.merchant_id == merchant["merchant_id"],
            )
        )
        material = r.scalar_one_or_none()
        if not material:
            raise HTTPException(404, "素材不存在或无权操作")

        # 删除物理文件
        abs_path = material.file_url.lstrip("/")
        if os.path.exists(abs_path):
            os.remove(abs_path)

        await db.delete(material)
        await db.commit()
        return {"status": "success"}

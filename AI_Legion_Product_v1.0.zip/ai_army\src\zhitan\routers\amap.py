﻿"""高德地图路由 - 周边POI搜索（后端Web服务Key）"""
from fastapi import APIRouter, Depends, HTTPException, Query
import httpx
from src.zhitan.config import AMAP_WEB_KEY

router = APIRouter()


@router.get("/around")
async def get_surrounding_pois(
    lng: float = Query(..., description="经度"),
    lat: float = Query(..., description="纬度"),
    radius: int = Query(500, ge=0, le=50000, description="搜索半径(米)"),
    keywords: str = Query(""),
    types: str = Query(""),
    page_size: int = Query(20, ge=1, le=25),
):
    """获取门店周边POI"""
    if not AMAP_WEB_KEY:
        raise HTTPException(500, "高德Web服务Key未配置")

    url = "https://restapi.amap.com/v5/place/around"
    params = {
        "key": AMAP_WEB_KEY,
        "location": f"{lng},{lat}",
        "radius": radius,
        "sortrule": "distance",
        "page_size": page_size,
        "output": "json",
    }
    if keywords:
        params["keywords"] = keywords
    if types:
        params["types"] = types

    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(url, params=params)
        data = r.json()

    if data.get("status") != "1":
        return {"status": "error", "message": data.get("info", "查询失败"), "pois": []}

    pois = data.get("pois", {}).get("poi", [])
    return {
        "status": "success",
        "pois": [
            {
                "name": p.get("name"),
                "type": p.get("type"),
                "address": p.get("address"),
                "location": p.get("location"),
                "distance": p.get("distance"),
                "business_area": p.get("business_area"),
            }
            for p in pois
        ],
    }


@router.get("/geo")
async def geocode(address: str = Query(..., description="地址")):
    """地理编码：地址转经纬度"""
    if not AMAP_WEB_KEY:
        raise HTTPException(500, "高德Web服务Key未配置")

    url = "https://restapi.amap.com/v3/geocode/geo"
    params = {"key": AMAP_WEB_KEY, "address": address, "output": "json"}

    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(url, params=params)
        data = r.json()

    if data.get("status") != "1":
        return {"status": "error", "message": "地址解析失败"}

    geocodes = data.get("geocodes", [])
    if not geocodes:
        return {"status": "error", "message": "未找到匹配坐标"}

    location = geocodes[0].get("location", "")
    lng, lat = location.split(",") if location else (None, None)
    return {
        "status": "success",
        "location": location,
        "lng": float(lng) if lng else None,
        "lat": float(lat) if lat else None,
        "formatted_address": geocodes[0].get("formatted_address", address),
    }


@router.get("/district")
async def get_district(
    keywords: str = Query("", description="行政区关键词（名称或adcode），空则返回省级"),
    subdistrict: int = Query(1, ge=0, le=3, description="返回下级行政区级数"),
):
    """获取行政区划数据（省市区级联）"""
    if not AMAP_WEB_KEY:
        raise HTTPException(500, "高德Web服务Key未配置，请在.env中设置 AMAP_WEB_KEY")

    url = "https://restapi.amap.com/v3/config/district"
    params = {
        "key": AMAP_WEB_KEY,
        "subdistrict": subdistrict,
        "extensions": "base",
        "output": "json",
    }
    if keywords:
        params["keywords"] = keywords

    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(url, params=params)
        data = r.json()

    if data.get("status") != "1":
        return {"status": "error", "message": data.get("info", "查询失败"), "districts": []}

    districts = data.get("districts", [])

    def fmt(d):
        return {
            "adcode": d.get("adcode"),
            "name": d.get("name"),
            "center": d.get("center"),
            "level": d.get("level"),
        }

    # 若传了 keywords，返回的第一个元素是查询的行政区本身，取其子级
    # 若没传 keywords，高德会返回 country 级别（中国）作为根，需取其子级（省级）
    if districts:
        root = districts[0]
        if root.get("level") == "country":
            children = root.get("districts", [])
            result = [fmt(c) for c in children]
        elif keywords:
            children = root.get("districts", [])
            result = [fmt(c) for c in children]
        else:
            result = [fmt(d) for d in districts]
    else:
        result = []

    return {"status": "success", "districts": result}


@router.get("/place/text")
async def search_place_text(
    keywords: str = Query(..., description="搜索关键词（商家/地点名称）"),
    city: str = Query("", description="城市/区域adcode限制"),
    citylimit: bool = Query(True, description="是否强制城市限制"),
    page_size: int = Query(20, ge=1, le=25),
):
    """关键词搜索POI（商家、地点）"""
    if not AMAP_WEB_KEY:
        raise HTTPException(500, "高德Web服务Key未配置，请在.env中设置 AMAP_WEB_KEY")

    url = "https://restapi.amap.com/v5/place/text"
    params = {
        "key": AMAP_WEB_KEY,
        "keywords": keywords,
        "page_size": page_size,
        "output": "json",
    }
    if city:
        params["city"] = city
        params["citylimit"] = "true" if citylimit else "false"

    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(url, params=params)
        data = r.json()

    if data.get("status") != "1":
        return {"status": "error", "message": data.get("info", "查询失败"), "pois": []}

    pois = data.get("pois", [])
    return {
        "status": "success",
        "pois": [
            {
                "id": p.get("id"),
                "name": p.get("name"),
                "type": p.get("type"),
                "address": p.get("address"),
                "location": p.get("location"),
                "cityname": p.get("cityname"),
                "adname": p.get("adname"),
                "pname": p.get("pname"),
            }
            for p in pois
        ],
    }


@router.get("/config")
async def get_amap_config():
    """获取前端高德地图配置（JS Key + 安全密钥）"""
    from src.zhitan.config import AMAP_JS_KEY, AMAP_JS_SECRET
    return {
        "status": "success",
        "js_key": AMAP_JS_KEY,
        "js_secret": AMAP_JS_SECRET,
    }

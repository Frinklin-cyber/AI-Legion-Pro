﻿"""Coze工作流 Webhook 回调路由"""
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

from sqlalchemy import select
from src.zhitan.models.database import async_session, GenerationTask

router = APIRouter()


class CozeProgressRequest(BaseModel):
    task_id: int
    workflow_id: str
    progress: int = 0
    stage: str = ""
    message: str = ""


class CozeCompleteRequest(BaseModel):
    task_id: int
    workflow_id: str
    video_urls: dict = {}
    thumbnail_url: Optional[str] = None
    script_content: Optional[dict] = None


class CozeErrorRequest(BaseModel):
    task_id: int
    workflow_id: str
    error: str


@router.post("/coze/progress")
async def coze_progress(req: CozeProgressRequest):
    """Coze推送生成进度"""
    async with async_session() as db:
        r = await db.execute(select(GenerationTask).where(GenerationTask.id == req.task_id))
        task = r.scalar_one_or_none()
        if not task:
            raise HTTPException(404, "任务不存在")
        task.progress = req.progress
        task.status = 1
        await db.commit()
    return {"status": "ok"}


@router.post("/coze/complete")
async def coze_complete(req: CozeCompleteRequest):
    """Coze推送生成完成"""
    async with async_session() as db:
        r = await db.execute(select(GenerationTask).where(GenerationTask.id == req.task_id))
        task = r.scalar_one_or_none()
        if not task:
            raise HTTPException(404, "任务不存在")
        task.status = 2
        task.progress = 100
        task.video_urls = req.video_urls
        task.thumbnail_url = req.thumbnail_url
        task.script_content = req.script_content
        task.completed_at = datetime.now()
        await db.commit()
    return {"status": "ok"}


@router.post("/coze/error")
async def coze_error(req: CozeErrorRequest):
    """Coze推送生成失败"""
    async with async_session() as db:
        r = await db.execute(select(GenerationTask).where(GenerationTask.id == req.task_id))
        task = r.scalar_one_or_none()
        if not task:
            raise HTTPException(404, "任务不存在")
        task.status = 3
        task.error_message = req.error
        await db.commit()
    return {"status": "ok"}

"""多租户数据模型 - 共享表 + tenant_id 隔离"""
import uuid
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, func
from src.db import Base


def _new_tenant_id() -> str:
    return uuid.uuid4().hex[:12]


class Merchant(Base):
    """商家表"""
    __tablename__ = "merchants"

    id = Column(Integer, primary_key=True, autoincrement=True)
    tenant_id = Column(String(32), unique=True, nullable=False, index=True, default=_new_tenant_id)
    name = Column(String(100), nullable=False, comment="商家名称")
    account = Column(String(100), unique=True, nullable=False, index=True, comment="登录账号")
    password_hash = Column(String(256), nullable=False, comment="bcrypt 密码哈希")
    phone = Column(String(30), default="", comment="联系电话")
    region = Column(String(100), default="", comment="所在地区")
    is_active = Column(Boolean, default=True, comment="是否启用")
    created_at = Column(DateTime, default=func.now(), comment="注册时间")


class ShopUser(Base):
    """商家员工表"""
    __tablename__ = "shop_users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    tenant_id = Column(String(32), nullable=False, index=True, comment="所属商家")
    name = Column(String(100), nullable=False, comment="员工姓名")
    phone = Column(String(30), default="", comment="手机号")
    role = Column(String(50), default="operator", comment="角色: admin/operator/viewer")
    is_active = Column(Boolean, default=True, comment="是否在职")
    created_at = Column(DateTime, default=func.now())


class BusinessData(Base):
    """业务数据表 - 存储商家信息、话术、客户等"""
    __tablename__ = "business_data"

    id = Column(Integer, primary_key=True, autoincrement=True)
    tenant_id = Column(String(32), nullable=False, index=True, comment="所属商家")
    data_type = Column(String(50), nullable=False, comment="数据类型: store_info/script/customer/content")
    content = Column(Text, default="{}", comment="JSON 格式内容")
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())


class UsageLog(Base):
    """使用记录表"""
    __tablename__ = "usage_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    tenant_id = Column(String(32), nullable=False, index=True, comment="所属商家")
    user_name = Column(String(100), default="", comment="操作用户")
    action = Column(String(300), default="", comment="操作描述")
    feature = Column(String(100), default="", comment="功能模块")
    created_at = Column(DateTime, default=func.now())

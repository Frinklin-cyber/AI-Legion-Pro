﻿"""DeepSeek API 服务 - 生成分镜脚本"""
import json
from typing import Optional

import httpx
from src.zhitan.config import DEEPSEEK_API_KEY, DEEPSEEK_BASE_URL


STORYBOARD_SYSTEM_PROMPT = """你是一个专业的短视频分镜脚本师，擅长为本地生活商家创作探店视频脚本。

请根据用户提供的商家信息，生成一份专业的竖屏探店视频分镜脚本。

要求：
1. 视频总时长 25-35 秒，至少 4 个场景
2. 字幕要口语化、有网感，适合抖音氛围
3. 每个场景包含：scene_no（编号）、duration（秒）、visual（画面描述，供AI生成图片/视频使用）、narration（旁白台词）、subtitle（显示字幕，带emoji）
4. 必须包含：门店外观/招牌 → 招牌菜/环境 → 特写/AI人设吃播 → 结尾引导关注
5. 旁白要用主播口吻，自然流畅

请严格按以下 JSON 格式输出（只输出 JSON，不要其他内容）：
{
  "total_duration": 30,
  "scenes": [
    {"scene_no": 1, "duration": 5, "visual": "...", "narration": "...", "subtitle": "..."},
    ...
  ],
  "bgm_suggestion": "轻快美食/探店Vlog风格",
  "hashtags": ["#xxx", "#xxx"]
}"""


async def generate_storyboard(
    store_info: dict,
    style_name: str = "专业探店",
    model: str = "deepseek-chat",
) -> dict:
    """根据门店信息生成分镜脚本

    Args:
        store_info: {"name", "category", "address", "specialty": [...], "atmosphere": "..."}
        style_name: 风格包名称
        model: 模型名（deepseek-chat 或 deepseek-reasoner）

    Returns:
        JSON 格式的分镜脚本
    """
    if not DEEPSEEK_API_KEY:
        raise RuntimeError("DEEPSEEK_API_KEY 未配置，请在 .env 中设置")

    user_prompt = f"""请为以下门店创作探店视频分镜脚本：

门店名称：{store_info.get('name', '未命名')}
品类：{store_info.get('category', '美食')}
地址：{store_info.get('address', '')}
特色卖点：{', '.join(store_info.get('specialty', [])) or '请自由发挥'}
氛围关键词：{store_info.get('atmosphere', '温馨热门')}
风格要求：{style_name}"""

    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json",
    }

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": STORYBOARD_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.8,
        "max_tokens": 3000,
        "response_format": {"type": "json_object"},
    }

    base = DEEPSEEK_BASE_URL.rstrip("/")
    # normalize to /v1 base
    if not base.endswith("/v1"):
        base = base + "/v1" if not base.endswith("/") else base + "v1"

    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(
            f"{base}/chat/completions",
            headers=headers,
            json=payload,
        )

    if r.status_code != 200:
        raise RuntimeError(f"DeepSeek API 调用失败 [{r.status_code}]: {r.text[:500]}")

    data = r.json()
    content = data["choices"][0]["message"]["content"].strip()

    # 清理可能的代码块标记
    if content.startswith("```json"):
        content = content[7:]
    if content.startswith("```"):
        content = content[3:]
    if content.endswith("```"):
        content = content[:-3]
    content = content.strip()

    try:
        script = json.loads(content)
    except json.JSONDecodeError:
        raise RuntimeError(f"DeepSeek 返回的分镜脚本非合法 JSON:\n{content[:500]}")

    if "scenes" not in script or not isinstance(script["scenes"], list):
        raise RuntimeError(f"分镜脚本缺少 scenes 字段:\n{json.dumps(script, ensure_ascii=False)[:500]}")

    script["_generated_by"] = model
    return script

import{x as s}from"./index-BVyUv5B8.js";const r={list:()=>s.get("/stores"),create:e=>s.post("/stores",e),update:(e,t)=>s.put(`/stores/${e}`,t),delete:e=>s.delete(`/stores/${e}`)};export{r as s};

﻿"""支付路由 - 创建订单、套餐余量、微信支付（MVP模拟）"""
import uuid
from datetime import datetime, date
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select

from src.zhitan.models.database import async_session, Order, MerchantQuota
from src.zhitan.routers.auth import get_current_merchant

router = APIRouter()


class CreateOrderRequest(BaseModel):
    order_type: int = Field(..., ge=1, le=2, description="1单条 2套餐")
    plan_name: str = Field(default="体验版")


# 套餐定价
PLANS = {
    "体验版": {"amount": 9.9, "description": "1条抖音竖版探店视频"},
    "标准版": {"amount": 99.0, "description": "4平台×4条/月 + 全部风格包", "quota": 16, "days": 30},
    "旗舰版": {"amount": 399.0, "description": "不限条数 + 全部风格包 + 优先生成", "quota": 999, "days": 30},
}


@router.post("/create-order")
async def create_order(req: CreateOrderRequest, merchant: dict = Depends(get_current_merchant)):
    """创建支付订单"""
    plan = PLANS.get(req.plan_name)
    if not plan:
        raise HTTPException(400, f"无效的套餐: {req.plan_name}")

    amount = plan["amount"]
    order_no = f"ZT{datetime.now().strftime('%Y%m%d%H%M%S')}{uuid.uuid4().hex[:6].upper()}"

    async with async_session() as db:
        order = Order(
            merchant_id=merchant["merchant_id"],
            order_no=order_no,
            order_type=req.order_type,
            plan_name=req.plan_name,
            amount=amount,
            status=0,
        )
        db.add(order)
        await db.commit()

    return {
        "status": "success",
        "order_no": order_no,
        "amount": amount,
        "plan_name": req.plan_name,
        "description": plan["description"],
        "message": "开发环境：支付已模拟完成",
    }


@router.get("/order/{order_no}")
async def get_order(order_no: str, merchant: dict = Depends(get_current_merchant)):
    """查询订单状态"""
    async with async_session() as db:
        r = await db.execute(
            select(Order).where(Order.order_no == order_no, Order.merchant_id == merchant["merchant_id"])
        )
        order = r.scalar_one_or_none()
        if not order:
            raise HTTPException(404, "订单不存在")

        return {
            "status": "success",
            "order": {
                "order_no": order.order_no,
                "order_type": order.order_type,
                "plan_name": order.plan_name,
                "amount": order.amount,
                "status": order.status,
                "paid_at": order.paid_at.isoformat() if order.paid_at else None,
                "created_at": order.created_at.isoformat() if order.created_at else None,
            },
        }


@router.post("/wechat/notify")
async def wechat_pay_notify():
    """微信支付回调（MVP模拟：直接标记已支付）"""
    # 正式环境：验证微信支付签名
    return {"code": "SUCCESS", "message": "OK"}


@router.post("/complete/{order_no}")
async def complete_order(order_no: str, merchant: dict = Depends(get_current_merchant)):
    """完成支付（开发环境模拟微信支付成功）"""
    async with async_session() as db:
        r = await db.execute(
            select(Order).where(Order.order_no == order_no, Order.merchant_id == merchant["merchant_id"])
        )
        order = r.scalar_one_or_none()
        if not order:
            raise HTTPException(404, "订单不存在")
        if order.status != 0:
            raise HTTPException(400, "订单状态异常")

        order.status = 1
        order.paid_at = datetime.now()
        order.payment_method = "wechat"

        # 更新套餐余量
        plan = PLANS.get(order.plan_name)
        if plan and "quota" in plan:
            r2 = await db.execute(
                select(MerchantQuota).where(MerchantQuota.merchant_id == merchant["merchant_id"])
            )
            quota = r2.scalar_one_or_none()
            if quota:
                quota.plan_type = order.plan_name
                quota.remaining_count += plan["quota"]
            else:
                quota = MerchantQuota(
                    merchant_id=merchant["merchant_id"],
                    plan_type=order.plan_name,
                    remaining_count=plan["quota"],
                    expire_at=date.today().replace(day=28) if date.today().day < 28 else None,
                )
                db.add(quota)
        else:
            # 体验版单条
            quota = MerchantQuota(
                merchant_id=merchant["merchant_id"],
                plan_type="experience",
                remaining_count=1,
            )
            db.add(quota)

        await db.commit()
        return {"status": "success", "message": "支付完成，套餐已到账"}


@router.get("")
async def get_quota(merchant: dict = Depends(get_current_merchant)):
    """查看套餐余量"""
    async with async_session() as db:
        r = await db.execute(
            select(MerchantQuota).where(MerchantQuota.merchant_id == merchant["merchant_id"])
        )
        quota = r.scalar_one_or_none()
        if not quota:
            return {"status": "success", "quota": {"plan_type": None, "remaining_count": 0, "expire_at": None}}
        return {
            "status": "success",
            "quota": {
                "plan_type": quota.plan_type,
                "remaining_count": quota.remaining_count,
                "expire_at": quota.expire_at.isoformat() if quota.expire_at else None,
            },
        }

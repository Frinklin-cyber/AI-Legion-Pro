﻿"""自动剪辑合成服务 - FFmpeg Pipeline

流水线：
  ① 文案质检（DeepSeek 校对多音字、错别字）
  ② TTS 生成配音（调用 tts_service）
  ③ ASR 对齐 → 生成字幕 SRT 时间轴
  ④ 素材匹配（即梦生成片段按分镜顺序匹配）
  ⑤ FFmpeg 合成：
     - 按分镜时序拼接
     - 混入配音 (+10dB) + BGM (-5dB)
     - 烧录字幕（字号24px，描边2px）
     - 添加转场效果（xfade）
     - 叠加显式水印："AI辅助制作" + "广告"双标识
  ⑥ 输出多平台版本：抖音9:16 / 小红书1:1 / 视频号16:9
  ⑦ 隐式标识：视频元数据写入 AIGC 标识信息
"""

import asyncio
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
import uuid
from typing import Optional

from src.zhitan.config import FFMPEG_PATH, DEEPSEEK_API_KEY

logger = logging.getLogger(__name__)


# ============================================================
# 平台输出配置
# ============================================================

PLATFORM_CONFIGS = {
    "douyin": {"label": "抖音", "ratio": "9:16", "width": 1080, "height": 1920},
    "xiaohongshu": {"label": "小红书", "ratio": "1:1", "width": 1080, "height": 1080},
    "shipinhao": {"label": "视频号", "ratio": "16:9", "width": 1920, "height": 1080},
}

# ============================================================
# 字幕 / 水印视觉参数
# ============================================================


def _get_font() -> str:
    """查找可用的中文字体"""
    candidates = [
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
        "C:/Windows/Fonts/simsun.ttc",
        "C:/Windows/Fonts/msyhbd.ttc",
        "C:/Windows/Fonts/STKAITI.TTF",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/System/Library/Fonts/PingFang.ttc",
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    return "C:/Windows/Fonts/msyh.ttc"  # 默认


_try_font = _get_font()


SUBTITLE_CONFIG = {
    "fontfile": _try_font,
    "fontsize": 24,
    "outline": 2,  # 描边宽度
    "outline_color": "black@0.6",  # 描边颜色+透明度
    "fontcolor": "white",
    "borderw": 0,  # box border
    "box": 1,  # 文本框背景
    "boxcolor": "black@0.45",
    "boxborderw": 8,  # 文本框圆角
    "alignment": 2,  # 底部居中
    "y_offset_ratio": 0.15,  # 距底部比例（竖屏）
}


WATERMARK_CONFIG = {
    "primary": "AI辅助制作",
    "secondary": "广告",
    "primary_alpha": 0.35,
    "secondary_alpha": 0.50,
    "fontfile": _try_font,
    "fontsize": 28,
    "fontcolor": "white",
    "borderw": 1,
    "bordercolor": "white@0.3",
}


# ============================================================
# BGM 配置（生成的静默 BGM 或可选真实 BGM）
# ============================================================

WORK_DIR = "static/output"
os.makedirs(WORK_DIR, exist_ok=True)


def _generate_silent_bgm(duration_sec: float, output_path: str) -> str:
    """生成静默 BGM 轨道（占位），供后续替换为真实 BGM"""
    cmd = [
        FFMPEG_PATH, "-y",
        "-f", "lavfi",
        "-i", f"anullsrc=r=44100:cl=stereo",
        "-t", str(duration_sec),
        "-q:a", "9",
        "-acodec", "libmp3lame",
        output_path,
    ]
    subprocess.run(cmd, capture_output=True, check=True, timeout=30)
    return output_path


def _silence_audio(duration_sec: float, output_path: str) -> str:
    """生成静默音频片段"""
    cmd = [
        FFMPEG_PATH, "-y",
        "-f", "lavfi",
        "-i", f"anullsrc=r=44100:cl=stereo",
        "-t", str(duration_sec),
        "-q:a", "9",
        "-acodec", "libmp3lame",
        output_path,
    ]
    subprocess.run(cmd, capture_output=True, check=True, timeout=30)
    return output_path


# ============================================================
# ① 文案质检 —— DeepSeek 校对多音字、错别字
# ============================================================

PROOFREAD_SYSTEM_PROMPT = """你是一个专业的短视频文案校对专家。请对以下探店视频口播文案进行校对：

检查项：
1. 多音字在口语场景下的正确读音标注
2. 错别字修正
3. 标点符号规范化（保持口语化停顿感）
4. 敏感词检查（不得影响内容合规）

要求：
- 保持原文的网感、口语化风格
- 只修改确有错误的地方，不要改写
- 以 JSON 格式输出，格式为：
{
  "scenes": [
    {"scene_no": 1, "original": "...", "corrected": "...", "changes": ["..."]},
    ...
  ],
  "overall_changes": 0,
  "notes": ""
}"""


async def proofread_script(scenes: list[dict]) -> list[dict]:
    """文案质检：调用 DeepSeek 校对多音字和错别字

    Args:
        scenes: [{scene_no, narration, subtitle}, ...]

    Returns:
        校对后的分镜，narration 替换为修正版
    """
    if not DEEPSEEK_API_KEY:
        logger.info("DeepSeek Key 未配置，跳过文案质检")
        return scenes

    narrations_text = "\n".join(
        f"分镜{s.get('scene_no','?')}: {s.get('narration','')}"
        for s in scenes if s.get("narration")
    )

    if not narrations_text:
        return scenes

    import httpx

    try:
        base = "https://api.deepseek.com/v1"
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": PROOFREAD_SYSTEM_PROMPT},
                {"role": "user", "content": narrations_text},
            ],
            "temperature": 0.3,
            "max_tokens": 2000,
            "response_format": {"type": "json_object"},
        }

        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(
                f"{base}/chat/completions",
                headers=headers,
                json=payload,
            )

        if r.status_code != 200:
            logger.warning(f"文案质检 API 调用失败 [{r.status_code}]，跳过校对")
            return scenes

        data = r.json()
        content = data["choices"][0]["message"]["content"].strip()
        if content.startswith("```json"):
            content = content[7:]
        if content.startswith("```"):
            content = content[3:]
        if content.endswith("```"):
            content = content[:-3]

        result = json.loads(content)
        proofed_scenes = result.get("scenes", [])

        # 应用修正
        scene_map = {str(s.get("scene_no", "")): s for s in proofed_scenes}
        for s in scenes:
            no = str(s.get("scene_no", ""))
            if no in scene_map:
                corrected = scene_map[no].get("corrected", "").strip()
                changes = scene_map[no].get("changes", [])
                if corrected and corrected != s.get("narration", ""):
                    logger.info(
                        f"分镜{no} 文案校对: {s.get('narration','')[:20]}... → {corrected[:20]}..."
                    )
                    s["narration"] = corrected
                    s["_proofread_changes"] = changes

        logger.info(
            f"文案质检完成，共修正 {result.get('overall_changes', 0)} 处: {result.get('notes', '')}"
        )
    except Exception as e:
        logger.warning(f"文案质检异常，使用原文: {e}")

    return scenes


# ============================================================
# ② TTS 生成配音 —— 调用 tts_service 模块
# ============================================================


async def generate_voiceovers(
    scenes: list[dict],
    voice: str = "zh_female_qingxin",
    speed: float = 1.15,
    work_dir: str = "",
) -> list[dict]:
    """为每个分镜生成配音音频

    Args:
        scenes: 分镜列表
        voice: 音色 ID
        speed: 语速倍率
        work_dir: 工作目录

    Returns:
        更新后的分镜，含 audio_path 字段
    """
    from src.zhitan.services.tts_service import generate_scene_audios

    if not work_dir:
        work_dir = os.path.join(WORK_DIR, f"tts_{uuid.uuid4().hex[:8]}")
    os.makedirs(work_dir, exist_ok=True)

    logger.info(f"TTS 配音生成中，音色={voice} 语速={speed}x，共 {len(scenes)} 条...")
    return await generate_scene_audios(
        scenes=scenes,
        voice=voice,
        speed=speed,
        output_dir=work_dir,
    )


# ============================================================
# ③ ASR 对齐 → 生成字幕 SRT
# ============================================================


def generate_srt(scenes: list[dict], speech_rate_cps: float = 4.5) -> str:
    """根据配音预估时长生成 SRT 字幕文件

    基于中文字数 × 语音速率 估算每句起止时间，累加得到时间轴。
    由 narration 文本作为字幕内容，保证语义一致。

    Args:
        scenes: 分镜列表（含 narration + audio_path 或音频时长）
        speech_rate_cps: 中文语音速率（字/秒），默认约4.5字/秒

    Returns:
        SRT 格式完整字符串
    """
    srt_lines = []
    subtitle_index = 1
    global_time = 0.0

    for scene in scenes:
        narration = scene.get("narration", "").strip()
        if not narration:
            continue

        # 优先用实际音频时长，否则用字数估算
        audio_dur = scene.get("audio_duration", 0)
        if not audio_dur or audio_dur <= 0:
            audio_dur = max(len(narration) / speech_rate_cps, 1.5)

        # 将每句话按逗号/句号/感叹号/问号拆分，使字幕更自然
        # 但保持每条的完整性
        sentences = _split_narration(narration)
        seg_count = len(sentences)
        seg_duration = audio_dur / seg_count if seg_count > 0 else audio_dur

        for seg in sentences:
            start = global_time
            end = global_time + seg_duration
            global_time = end

            srt_lines.append(str(subtitle_index))
            srt_lines.append(
                f"{_fmt_srt_time(start)} --> {_fmt_srt_time(end)}"
            )
            srt_lines.append(seg)
            srt_lines.append("")  # 空行分隔
            subtitle_index += 1

        # 场景间暂停 0.3 秒
        global_time += 0.3

    return "\n".join(srt_lines)


def _fmt_srt_time(seconds: float) -> str:
    """格式化 SRT 时间戳 HH:MM:SS,mmm"""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds - int(seconds)) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _split_narration(text: str) -> list:
    """智能拆句：按标点拆分，保证每段至少4个字"""
    raw_parts = re.split(r"([，。！？!?\n…—])", text)

    parts = []
    current = ""
    for p in raw_parts:
        current += p
        if p in ("，", "。", "！", "？", "!", "?", "\n", "…", "—"):
            if len(current.strip()) >= 4:
                parts.append(current.strip())
                current = ""

    if current.strip():
        parts.append(current.strip())

    # 如果拆分后太碎，合并为单句
    if not parts:
        parts = [text.strip()]
    if len(parts) <= 1:
        return [text.strip()]

    return parts


# ============================================================
# ④ 素材匹配
# ============================================================


async def match_materials(
    scenes: list[dict],
    image_paths: list[str],
    video_clips: list = None,
    use_video: bool = False,
) -> list[dict]:
    """将即梦素材按分镜顺序匹配

    Args:
        scenes: 分镜列表
        image_paths: 关键帧图片路径
        video_clips: 视频片段路径（可选）
        use_video: 是否使用视频片段（默认用图片+音频合成）

    Returns:
        更新后的分镜，含 matched_image 字段
    """
    for i, scene in enumerate(scenes):
        # 图片匹配：按序号取模
        if image_paths:
            idx = i % len(image_paths)
            scene["matched_image"] = image_paths[idx]
        else:
            scene["matched_image"] = _generate_placeholder_image(i + 1)

        # 视频匹配
        if use_video and video_clips:
            idx = i % len(video_clips)
            scene["matched_video"] = video_clips[idx]
        elif use_video and image_paths:
            scene["matched_video"] = scene.get("matched_image", "")  # 降级为图片
        else:
            scene["matched_video"] = ""

    return scenes


def _generate_placeholder_image(scene_no: int) -> str:
    """生成占位图片（纯色背景+文字）"""
    try:
        from PIL import Image, ImageDraw, ImageFont

        W, H = 1080, 1920
        img = Image.new("RGB", (W, H), color=(15, 15, 35))
        draw = ImageDraw.Draw(img)

        try:
            font = ImageFont.truetype(_get_font(), 60)
            font_sm = ImageFont.truetype(_get_font(), 36)
        except Exception:
            font = ImageFont.load_default()
            font_sm = font

        draw.rectangle([40, 40, W - 40, H - 40], outline=(60, 60, 100), width=4)
        draw.text((W // 2 - 200, H // 2 - 50), f"场景 {scene_no}", fill=(200, 200, 255), font=font)
        draw.text((W // 2 - 260, H // 2 + 40), "AI生成探店画面", fill=(150, 150, 200), font=font_sm)
        draw.rectangle(
            [W // 2 - 150, H // 2 + 90, W // 2 + 150, H // 2 + 96],
            fill=(0, 180, 255),
        )

        out_dir = os.path.join(WORK_DIR, "placeholders")
        os.makedirs(out_dir, exist_ok=True)
        out = os.path.join(out_dir, f"scene_{scene_no:02d}.png")
        img.save(out)
        return out
    except Exception:
        return ""


# ============================================================
# ⑤ FFmpeg 合成（核心）
# ============================================================


async def assemble_video(
    scenes: list[dict],
    output_path: str,
    platform: str = "douyin",
    bgm_path: str = "",
    total_duration: float = 30.0,
) -> str:
    """FFmpeg 合成探店主视频

    流程：
    1. 为每个分镜生成带字幕的画面片段
    2. 串联所有片段 + 转场
    3. 混入配音 + BGM
    4. 叠加水印

    Args:
        scenes: 分镜列表（含 matched_image/audio_path）
        output_path: 输出路径
        platform: 平台（douyin/xiaohongshu/shipinhao）
        bgm_path: BGM 音频路径
        total_duration: 预估总时长

    Returns:
        输出视频路径
    """
    pc = PLATFORM_CONFIGS.get(platform, PLATFORM_CONFIGS["douyin"])
    W, H = pc["width"], pc["height"]

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    temp_dir = os.path.join(WORK_DIR, f"assemble_{uuid.uuid4().hex[:8]}")
    os.makedirs(temp_dir, exist_ok=True)

    # ---- 步骤 1: 每个分镜生成画面片段（图片 + 字幕 + 配音） ----
    segment_files = []
    for scene in scenes:
        img = scene.get("matched_image", "")
        aud = scene.get("audio_path", "")
        narration = scene.get("narration", "")
        duration = scene.get("audio_duration", scene.get("duration", 5))

        seg_path = os.path.join(temp_dir, f"seg_{scene.get('scene_no', 0):02d}.mp4")
        _build_scene_segment(
            image_path=img,
            audio_path=aud,
            subtitle_text=narration,
            duration=duration,
            output=seg_path,
            width=W,
            height=H,
            scene_no=scene.get("scene_no", 0),
        )
        if os.path.exists(seg_path):
            segment_files.append(seg_path)

    if not segment_files:
        raise RuntimeError("没有可用的视频片段")

    # ---- 步骤 2: 串联 + 转场 ----
    concat_path = os.path.join(temp_dir, "concat.mp4")
    _concat_with_transitions(segment_files, concat_path, W, H)

    # ---- 步骤 3: 混入 BGM ----
    if bgm_path and os.path.exists(bgm_path):
        mixed_path = os.path.join(temp_dir, "mixed.mp4")
        _mix_bgm(concat_path, bgm_path, mixed_path)
        concat_path = mixed_path

    # ---- 步骤 4: 叠加水印 ----
    _add_watermark(concat_path, output_path, W, H)

    # 清理临时文件
    try:
        shutil.rmtree(temp_dir)
    except Exception:
        pass

    logger.info(f"视频合成完成 [{platform}]: {output_path}")
    return output_path


def _build_scene_segment(
    image_path: str,
    audio_path: str,
    subtitle_text: str,
    duration: float,
    output: str,
    width: int,
    height: int,
    scene_no: int = 0,
):
    """构建单个场景片段：图片 + 缩放动画 + 字幕 + 配音"""
    if not image_path or not os.path.exists(image_path):
        image_path = _generate_placeholder_image(scene_no)

    duration = max(duration, 1.5)  # 最少 1.5 秒

    # 字幕文字净化（移除 FFmpeg 特殊字符）
    clean_subtitle = _escape_subtitle(subtitle_text or "")

    # 字幕 Y 坐标
    sub_y = int(height * (1.0 - SUBTITLE_CONFIG["y_offset_ratio"]))
    sub_font = SUBTITLE_CONFIG["fontfile"]
    sub_size = SUBTITLE_CONFIG["fontsize"]
    outline = SUBTITLE_CONFIG["outline"]

    # 构建 drawtext 滤镜
    # 字幕 + 描边 + 半透明背景框
    subtitle_filter = (
        f"drawtext=fontfile='{sub_font}':"
        f"text='{clean_subtitle}':"
        f"fontsize={sub_size}:"
        f"fontcolor={SUBTITLE_CONFIG['fontcolor']}:"
        f"bordercolor={SUBTITLE_CONFIG['outline_color']}:"
        f"borderw={outline}:"
        f"box={SUBTITLE_CONFIG['box']}:"
        f"boxcolor={SUBTITLE_CONFIG['boxcolor']}:"
        f"boxborderw={SUBTITLE_CONFIG['boxborderw']}:"
        f"x=(w-text_w)/2:"
        f"y={sub_y}-text_h:"
        f"enable='between(t,0,{duration})'"
    )

    # 缩放 + 字幕滤镜（简化版，更高兼容性）
    # 先用 scale 确保尺寸正确，再叠加字幕
    filters = (
        f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
        f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,"
        f"{subtitle_filter},format=yuv420p"
    )

    if audio_path and os.path.exists(audio_path):
        cmd = [
            FFMPEG_PATH, "-y",
            "-loop", "1",
            "-i", image_path,
            "-i", audio_path,
            "-vf", filters,
            "-c:v", "libx264",
            "-preset", "ultrafast",
            "-crf", "23",
            "-pix_fmt", "yuv420p",
            "-t", str(duration),
            "-shortest",
            "-c:a", "aac",
            "-b:a", "128k",
            output,
        ]
    else:
        silent_audio = os.path.join(os.path.dirname(output), f"silent_{scene_no}.mp3")
        _silence_audio(duration, silent_audio)
        cmd = [
            FFMPEG_PATH, "-y",
            "-loop", "1",
            "-i", image_path,
            "-i", silent_audio,
            "-vf", filters,
            "-c:v", "libx264",
            "-preset", "ultrafast",
            "-crf", "23",
            "-pix_fmt", "yuv420p",
            "-t", str(duration),
            "-shortest",
            "-c:a", "aac",
            "-b:a", "128k",
            output,
        ]

    try:
        r = subprocess.run(cmd, capture_output=True, text=False, timeout=60)
        if r.returncode != 0:
            err = r.stderr.decode("utf-8", errors="replace")[:300] if r.stderr else ""
            logger.warning(f"场景片段生成失败: {err}")
            _build_simple_segment(image_path, duration, output, width, height)
    except Exception as e:
        logger.warning(f"场景片段生成异常: {e}")
        _build_simple_segment(image_path, duration, output, width, height)


def _build_simple_segment(
    image_path: str,
    duration: float,
    output: str,
    width: int,
    height: int,
):
    """简单片段：仅图片+静音（降级方案）"""
    silent_audio = os.path.join(os.path.dirname(output), "silent_fallback.mp3")
    _silence_audio(duration, silent_audio)
    cmd = [
        FFMPEG_PATH, "-y",
        "-loop", "1",
        "-i", image_path,
        "-i", silent_audio,
        "-vf", f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
               f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,format=yuv420p",
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-crf", "23",
        "-pix_fmt", "yuv420p",
        "-t", str(duration),
        "-shortest",
        "-c:a", "aac",
        "-b:a", "128k",
        output,
    ]
    subprocess.run(cmd, capture_output=True, text=False, timeout=60)


def _concat_with_transitions(
    segment_files: list[str],
    output: str,
    width: int,
    height: int,
):
    """串联所有片段（带 xfade 转场）"""
    if len(segment_files) == 1:
        shutil.copy(segment_files[0], output)
        return

    # 用 concat filter 串联
    inputs = []
    for f in segment_files:
        inputs.extend(["-i", f])

    # 构建 filter_complex
    n = len(segment_files)
    filter_parts = []

    # 先 normalize 每个输入
    for i in range(n):
        filter_parts.append(
            f"[{i}:v]scale={width}:{height},setsar=1,fps=25,format=yuv420p[v{i}];"
        )

    # 串联 video
    concat_inputs = "".join(f"[v{i}]" for i in range(n))
    filter_parts.append(f"{concat_inputs}concat=n={n}:v=1:a=0[vout];")

    # 串联 audio
    audio_parts = "".join(f"[{i}:a]" for i in range(n))
    filter_parts.append(f"{audio_parts}concat=n={n}:v=0:a=1[aout]")

    filter_str = "".join(filter_parts)

    cmd = [
        FFMPEG_PATH, "-y",
        *inputs,
        "-filter_complex", filter_str,
        "-map", "[vout]",
        "-map", "[aout]",
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-crf", "23",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-b:a", "128k",
        output,
    ]

    try:
        r = subprocess.run(cmd, capture_output=True, text=False, timeout=120)
        if r.returncode != 0:
            err = r.stderr.decode("utf-8", errors="replace")[:300] if r.stderr else ""
            logger.warning(f"串联失败: {err}")
            if os.path.exists(segment_files[0]):
                shutil.copy(segment_files[0], output)
    except Exception as e:
        logger.warning(f"串联异常: {e}")
        if os.path.exists(segment_files[0]):
            shutil.copy(segment_files[0], output)


def _mix_bgm(
    video_path: str,
    bgm_path: str,
    output: str,
):
    """混入 BGM：配音 +10dB，BGM -5dB"""
    # 获取视频中的音频流混入 BGM
    cmd = [
        FFMPEG_PATH, "-y",
        "-i", video_path,
        "-stream_loop", "-1",
        "-i", bgm_path,
        "-filter_complex",
        "[0:a]volume=10dB[a0];[1:a]volume=-5dB,afade=t=in:d=0.5,afade=t=out:st=9999:d=1[a1];"
        "[a0][a1]amix=inputs=2:duration=first:dropout_transition=2[aout]",
        "-map", "0:v",
        "-map", "[aout]",
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",
        output,
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, text=False, timeout=120)
        if r.returncode != 0:
            err = r.stderr.decode("utf-8", errors="replace")[:300] if r.stderr else ""
            logger.warning(f"BGM 混入失败: {err}")
            shutil.copy(video_path, output)
    except Exception as e:
        logger.warning(f"BGM 混入异常: {e}")
        shutil.copy(video_path, output)


def _add_watermark(
    video_path: str,
    output: str,
    width: int,
    height: int,
):
    """叠加双水印："AI辅助制作" + "广告" """
    font = WATERMARK_CONFIG["fontfile"]
    primary = WATERMARK_CONFIG["primary"]
    secondary = WATERMARK_CONFIG["secondary"]
    fontsize = WATERMARK_CONFIG["fontsize"]
    fontcolor = WATERMARK_CONFIG["fontcolor"]
    alpha1 = WATERMARK_CONFIG["primary_alpha"]
    alpha2 = WATERMARK_CONFIG["secondary_alpha"]

    # 主水印 - 右上角
    padding_x = 30
    padding_y = 30

    primary_filter = (
        f"drawtext=fontfile='{font}':"
        f"text='{primary}':"
        f"fontsize={fontsize}:"
        f"fontcolor={fontcolor}@{alpha1}:"
        f"borderw=1:"
        f"bordercolor=white@0.2:"
        f"x=w-text_w-{padding_x}:"
        f"y={padding_y}"
    )

    # 副水印 - 左上角
    secondary_filter = (
        f"drawtext=fontfile='{font}':"
        f"text='{secondary}':"
        f"fontsize=24:"
        f"fontcolor=white@{alpha2}:"
        f"borderw=1:"
        f"bordercolor=red@0.4:"
        f"x={padding_x}:"
        f"y={padding_y}"
    )

    cmd = [
        FFMPEG_PATH, "-y",
        "-i", video_path,
        "-vf", f"{primary_filter},{secondary_filter}",
        "-c:a", "copy",
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-crf", "23",
        output,
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, text=False, timeout=120)
        if r.returncode != 0:
            err = r.stderr.decode("utf-8", errors="replace")[:300] if r.stderr else ""
            logger.warning(f"水印叠加失败: {err}")
            shutil.copy(video_path, output)
    except Exception as e:
        logger.warning(f"水印叠加异常: {e}")
        shutil.copy(video_path, output)


def _escape_subtitle(text: str) -> str:
    """转义字幕中的 FFmpeg drawtext 特殊字符"""
    escapes = {
        ":": "\\:",
        "'": "\\'",
        "%": "\\%",
        "{": "\\{",
        "}": "\\}",
        "\\": "\\\\",
        "\n": " ",
    }
    # 先处理反斜杠，再处理其他
    result = text
    for char, escaped in sorted(escapes.items(), key=lambda x: -len(x[0])):
        result = result.replace(char, escaped)
    return result


# ============================================================
# ⑥ 多平台输出
# ============================================================


async def render_multi_platform(
    scenes: list[dict],
    output_dir: str,
    bgm_path: str = "",
    total_duration: float = 30.0,
    platforms: list = None,
) -> dict:
    """生成多平台版本

    Returns:
        {platform_id: output_path, ...}
    """
    if platforms is None:
        platforms = ["douyin", "xiaohongshu", "shipinhao"]

    results = {}
    for p in platforms:
        if p not in PLATFORM_CONFIGS:
            continue
        pc = PLATFORM_CONFIGS[p]
        out_path = os.path.join(output_dir, f"video_{p}.mp4")

        # 根据平台裁剪
        if p == "xiaohongshu":
            out_path = await _render_1x1(scenes, output_dir, bgm_path, total_duration)
        elif p == "shipinhao":
            out_path = await _render_16x9(scenes, output_dir, bgm_path, total_duration)
        else:
            out_path = await assemble_video(
                scenes=scenes,
                output_path=out_path,
                platform=p,
                bgm_path=bgm_path,
                total_duration=total_duration,
            )

        if os.path.exists(out_path):
            results[p] = out_path
            logger.info(f"[{pc['label']}] 输出: {out_path}")

    return results


async def _render_1x1(scenes, output_dir, bgm_path, total_duration):
    """渲染小红书 1:1 版本（裁剪竖屏中间部分）"""
    temp_9x16 = os.path.join(output_dir, "temp_douyin.mp4")
    await assemble_video(
        scenes=scenes,
        output_path=temp_9x16,
        platform="douyin",
        bgm_path=bgm_path,
        total_duration=total_duration,
    )
    out = os.path.join(output_dir, "video_xiaohongshu.mp4")
    # 从 1080x1920 裁剪为 1080x1080，居中
    cmd = [
        FFMPEG_PATH, "-y",
        "-i", temp_9x16,
        "-vf", "crop=1080:1080:0:(in_h-1080)/2",
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-crf", "23",
        "-c:a", "copy",
        out,
    ]
    subprocess.run(cmd, capture_output=True, timeout=60)
    return out


async def _render_16x9(scenes, output_dir, bgm_path, total_duration):
    """渲染视频号 16:9 版本（竖屏居中 + 模糊背景左右填充）"""
    temp_9x16 = os.path.join(output_dir, "temp_douyin_16x9.mp4")
    await assemble_video(
        scenes=scenes,
        output_path=temp_9x16,
        platform="douyin",
        bgm_path=bgm_path,
        total_duration=total_duration,
    )
    out = os.path.join(output_dir, "video_shipinhao.mp4")
    # 从 1080x1920 → 1920x1080，居中 + 高斯模糊背景
    cmd = [
        FFMPEG_PATH, "-y",
        "-i", temp_9x16,
        "-vf",
        "split[original][copy];"
        "[copy]scale=1920:1080:force_original_aspect_ratio=increase,"
        "crop=1920:1080,gblur=sigma=20[bg];"
        "[original]scale=608:1080:force_original_aspect_ratio=decrease[fg];"
        "[bg][fg]overlay=(W-w)/2:0",
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-crf", "23",
        "-c:a", "copy",
        out,
    ]
    subprocess.run(cmd, capture_output=True, timeout=60)
    return out


# ============================================================
# ⑦ 隐式标识 —— AIGC 元数据写入
# ============================================================


def write_aigc_metadata(
    video_path: str,
    metadata: dict = None,
):
    """在视频文件元数据中写入 AIGC 标识信息

    参考《人工智能生成合成内容标识办法》
    """
    if metadata is None:
        metadata = {
            "AIGC_Generated": "true",
            "AIGC_Provider": "智探AI",
            "AIGC_Model": "DeepSeek + Jimeng + Doubao TTS",
            "AIGC_Timestamp": "",
            "AIGC_Watermark_Visible": "AI辅助制作 + 广告",
            "AIGC_Compliance": "参照《人工智能生成合成内容标识办法》",
        }

    from datetime import datetime
    metadata["AIGC_Timestamp"] = metadata.get(
        "AIGC_Timestamp", datetime.now().isoformat()
    )

    # 构建 metadata 参数字符串
    meta_args = []
    for k, v in metadata.items():
        meta_args.extend(["-metadata", f"{k}={v}"])

    tmp_output = video_path + ".meta_tmp.mp4"
    cmd = [
        FFMPEG_PATH, "-y",
        "-i", video_path,
        *meta_args,
        "-c", "copy",
        tmp_output,
    ]

    try:
        r = subprocess.run(cmd, capture_output=True, text=False, timeout=120)
        if r.returncode == 0:
            os.replace(tmp_output, video_path)
            logger.info(f"AIGC 隐式标识写入完成: {list(metadata.keys())}")
        else:
            err = r.stderr.decode("utf-8", errors="replace")[:200] if r.stderr else ""
            logger.warning(f"元数据写入失败（不影响主流程）: {err}")
    except Exception as e:
        logger.warning(f"元数据写入异常（不影响主流程）: {e}")


# ============================================================
# 全流程编排
# ============================================================


async def full_pipeline(
    scenes: list[dict],
    image_paths: list[str],
    output_dir: str = "",
    voice: str = "zh_female_qingxin",
    speed: float = 1.15,
    bgm_path: str = "",
    platforms: list = None,
    use_video: bool = False,
    video_clips: list = None,
) -> dict:
    """全自动剪辑合成流水线

    ① 文案质检
    ② TTS 配音
    ③ SRT 字幕
    ④ 素材匹配
    ⑤→⑦ FFmpeg 合成 + 多平台 + AIGC 标识

    Args:
        scenes: 分镜列表 [{scene_no, visual, narration, subtitle, duration}, ...]
        image_paths: 关键帧图片路径
        output_dir: 输出目录
        voice: TTS 音色
        speed: TTS 语速
        bgm_path: BGM 音频路径（可选）
        platforms: 输出平台列表（默认全平台）
        use_video: 是否使用即梦视频（默认用图片）
        video_clips: 视频片段路径

    Returns:
        {
            "scenes": [...],           # 更新后的分镜（含 audio_path）
            "srt": "SRT字幕内容...",
            "outputs": {"douyin": "...", ...},
            "total_duration": 30.0,
        }
    """
    if not output_dir:
        output_dir = os.path.join(WORK_DIR, f"pipeline_{uuid.uuid4().hex[:8]}")
    os.makedirs(output_dir, exist_ok=True)

    # ① 文案质检
    logger.info("流水线 ① 文案质检...")
    scenes = await proofread_script(scenes)

    # ② TTS 配音
    logger.info("流水线 ② TTS 配音生成...")
    tts_dir = os.path.join(output_dir, "tts")
    scenes = await generate_voiceovers(
        scenes=scenes,
        voice=voice,
        speed=speed,
        work_dir=tts_dir,
    )

    # 计算实际总时长
    total_duration = sum(
        s.get("audio_duration", s.get("duration", 5)) for s in scenes
    ) + 0.3 * max(len(scenes) - 1, 0)

    # ③ SRT 字幕
    logger.info("流水线 ③ ASR 对齐 → SRT 字幕...")
    srt_content = generate_srt(scenes)
    srt_path = os.path.join(output_dir, "subtitles.srt")
    with open(srt_path, "w", encoding="utf-8") as f:
        f.write(srt_content)

    # ④ 素材匹配
    logger.info("流水线 ④ 素材匹配...")
    scenes = await match_materials(
        scenes=scenes,
        image_paths=image_paths,
        video_clips=video_clips,
        use_video=use_video,
    )

    # ⑤→⑦ FFmpeg 合成 + 多平台 + AIGC
    logger.info("流水线 ⑤→⑦ FFmpeg 合成 + 多平台输出...")
    if platforms is None:
        platforms = ["douyin", "xiaohongshu", "shipinhao"]

    outputs = {}
    for p in platforms:
        if p not in PLATFORM_CONFIGS:
            continue
        out_path = os.path.join(output_dir, f"video_{p}.mp4")

        if p == "xiaohongshu":
            out_path = await _render_1x1(scenes, output_dir, bgm_path, total_duration)
        elif p == "shipinhao":
            out_path = await _render_16x9(scenes, output_dir, bgm_path, total_duration)
        else:
            out_path = await assemble_video(
                scenes=scenes,
                output_path=out_path,
                platform=p,
                bgm_path=bgm_path,
                total_duration=total_duration,
            )

        # ⑦ 隐式标识
        if os.path.exists(out_path):
            write_aigc_metadata(out_path)
            outputs[p] = out_path

    # 生成 BGM（无声）
    if not bgm_path or not os.path.exists(bgm_path):
        bgm_out = os.path.join(output_dir, "bgm_silent.mp3")
        _generate_silent_bgm(total_duration, bgm_out)
        outputs["_bgm"] = bgm_out

    logger.info(
        f"全流程完成: {len(outputs)-1} 个平台版本, 总时长 {total_duration:.1f}s"
    )

    return {
        "scenes": scenes,
        "srt": srt_content,
        "srt_path": srt_path,
        "outputs": outputs,
        "total_duration": total_duration,
    }

﻿"""生成流水线主控制器 - 编排 Kimi → DeepSeek → 即梦 → TTS → FFmpeg

流水线阶段：
  [0] Kimi K2.6 多模态分析 → 结构化卖点 JSON
  [1] DeepSeek 基于卖点 → 分镜脚本
  [2] 即梦 t2i → 关键帧图片
  [3] 文案质检 ← DeepSeek 校对多音字/错别字 (新增)
  [4] 火山方舟 Ark TTS → 配音 (新增，替换 Edge-TTS)
  [5] ASR 对齐 → SRT 字幕 (新增)
  [6] FFmpeg 全自动合成：
      - 按分镜时序拼接 + 字幕烧录 + 转场
      - BGM 混入（配音+10dB / BGM-5dB）
      - 双水印："AI辅助制作" + "广告"
      - 多平台：抖音9:16 / 小红书1:1 / 视频号16:9
      - AIGC 隐式元数据
"""

import asyncio
import glob
import json
import logging
import os
import shutil
from datetime import datetime
from typing import Callable, Optional

from src.zhitan.models.database import async_session, GenerationTask, Store, Material
from sqlalchemy import select

logger = logging.getLogger(__name__)

WORK_DIR = "static/output"
os.makedirs(WORK_DIR, exist_ok=True)

# 默认 TTS 参数
DEFAULT_VOICE = os.getenv("TTS_DEFAULT_VOICE", "zh_female_qingxin")
DEFAULT_SPEED = float(os.getenv("TTS_DEFAULT_SPEED", "1.15"))


class GenerationPipeline:
    """视频生成完整流水线"""

    def __init__(self, task_id: int, state_callback: Optional[Callable] = None):
        self.task_id = task_id
        self.state_callback = state_callback  # Celery update_state
        self.task_dir = os.path.join(WORK_DIR, f"task_{task_id}")
        self.images_dir = os.path.join(self.task_dir, "images")
        self.audio_dir = os.path.join(self.task_dir, "audio")
        os.makedirs(self.images_dir, exist_ok=True)
        os.makedirs(self.audio_dir, exist_ok=True)

    async def execute(self) -> dict:
        """执行完整流水线"""
        task_data = await self._get_task_data()

        # 检查是否已有预设剧本（来自采访模式或 script_content 预填充）
        preset_storyboard = None
        if task_data.get("script_content") and task_data["script_content"].get("scenes"):
            preset_storyboard = task_data["script_content"]
            logger.info(f"任务 {self.task_id}: 检测到预设剧本（采访模式），跳过分析步骤")

        if preset_storyboard:
            # 跳过 ⓪ Kimi 分析 + ① DeepSeek 生成，直接进入图片/TTS/剪辑
            storyboard = preset_storyboard
            selling_points = preset_storyboard.get("_kimi_analysis", {})
            await self._update_progress(10, "已加载采访剧本...")
        else:
            # ⓪ Kimi K2.6 多模态卖点分析 (0-10%)
            await self._update_progress(2, "Kimi 分析素材抽取卖点...")
            selling_points, context_brief = await self._step_kimi_analysis(task_data)

            # ① DeepSeek 基于卖点生成分镜脚本 (10-25%)
            await self._update_progress(10, "DeepSeek 生成分镜脚本...")
            storyboard = await self._step_storyboard(task_data, selling_points, context_brief)

        # ② 即梦生成关键帧图片 (25-45%)
        await self._update_progress(25, "即梦生成关键帧图片...")
        image_paths = await self._step_generate_images(storyboard)

        # ③ 文案质检 (45-50%)
        await self._update_progress(45, "文案质检校对...")
        storyboard["scenes"] = await self._step_proofread(storyboard["scenes"])

        # ④ 火山方舟 TTS 配音 (50-70%)
        await self._update_progress(50, "AI 生成配音...")
        storyboard["scenes"] = await self._step_tts(storyboard["scenes"])

        # ⑤ 全自动剪辑合成 (70-95%)
        await self._update_progress(70, "FFmpeg 智能剪辑合成...")
        outputs = await self._step_assemble(storyboard, image_paths)

        # ⑥ 存储 + 更新数据库 (95-100%)
        await self._update_progress(95, "存储成片...")
        video_urls = await self._step_store(outputs)

        # 完成
        await self._mark_completed(video_urls, storyboard, selling_points)
        await self._update_progress(100, "生成完成")

        return {"status": "completed", "video_urls": video_urls, "outputs": outputs}

    # =============== 各步骤实现 ===============

    async def _step_kimi_analysis(self, task_data: dict) -> tuple[dict, str]:
        """步骤 0: Kimi K2.6 多模态素材分析 → 结构化卖点

        Returns:
            (selling_points_json, context_brief_string)
            失败时返回空 dict 和空字符串（优雅降级）
        """
        from src.zhitan.services.kimi_service import analyze_materials
        from src.zhitan.config import KIMI_API_KEY

        store_info = {
            "name": task_data["store_name"],
            "category": task_data["category"],
            "address": task_data["address"],
            "description": task_data.get("description", "") or task_data.get("atmosphere", ""),
        }

        material_paths = task_data.get("material_paths", [])

        if not KIMI_API_KEY:
            logger.info("Kimi Key 未配置，跳过素材分析")
            return {}, ""

        if not material_paths:
            logger.info("任务无素材文件，使用纯文本卖点抽取")
            try:
                from src.zhitan.services.kimi_service import extract_selling_points_text_only
                sp = await extract_selling_points_text_only(store_info)
                return sp, ""
            except Exception as e:
                logger.warning(f"Kimi 文本卖点分析失败: {e}")
                return {}, ""

        try:
            sp = await analyze_materials(
                material_paths=material_paths,
                store_info=store_info,
            )
            # 可选：生成创作上下文摘要
            context = ""
            try:
                from src.zhitan.services.kimi_service import enhance_storyboard_context
                context = await enhance_storyboard_context(sp, store_info)
            except Exception:
                pass
            return sp, context
        except Exception as e:
            logger.warning(f"Kimi 多模态分析失败，回退到纯文本分析: {e}")
            try:
                from src.zhitan.services.kimi_service import extract_selling_points_text_only
                sp = await extract_selling_points_text_only(store_info)
                return sp, ""
            except Exception:
                logger.warning("Kimi 纯文本分析也失败，跳过卖点抽取")
                return {}, ""

    async def _get_task_data(self) -> dict:
        """读取任务、门店和素材数据"""
        async with async_session() as db:
            r = await db.execute(
                select(GenerationTask).where(GenerationTask.id == self.task_id)
            )
            task = r.scalar_one_or_none()
            if not task:
                raise RuntimeError(f"任务 {self.task_id} 不存在")

            r2 = await db.execute(
                select(Store).where(Store.id == task.store_id)
            )
            store = r2.scalar_one_or_none()
            if not store:
                raise RuntimeError(f"门店 {task.store_id} 不存在")

            # 读取素材文件路径
            material_paths = []
            material_ids = task.material_ids or []
            if material_ids:
                r3 = await db.execute(
                    select(Material).where(Material.id.in_(material_ids))
                )
                materials = r3.scalars().all()
                for m in materials:
                    local_path = m.file_url.lstrip("/")
                    if os.path.exists(local_path):
                        material_paths.append(local_path)

        return {
            "task": task,
            "store": store,
            "store_name": store.store_name or "未命名门店",
            "category": store.category or "美食",
            "address": store.address or "",
            "description": getattr(store, "description", "") or "",
            "specialty": (store.selling_points or {}).get("highlights", []) if store.selling_points else [],
            "atmosphere": (store.selling_points or {}).get("atmosphere", "") if store.selling_points else "",
            "style_pack_id": task.style_pack_id,
            "material_paths": material_paths,
            "material_ids": material_ids,
            "script_content": task.script_content,  # 预设剧本（来自采访模式）
        }

    async def _step_storyboard(
        self,
        task_data: dict,
        selling_points: Optional[dict] = None,
        context_brief: str = "",
    ) -> dict:
        """步骤 1: DeepSeek 生成分镜脚本（融合 Kimi 卖点）"""
        from src.zhitan.services.deepseek_service import generate_storyboard
        from src.zhitan.config import DEEPSEEK_API_KEY

        # 构建增强的 store_info（融入 Kimi 卖点）
        sp = selling_points or {}

        highlights = (
            sp.get("highlights", []) or
            task_data.get("specialty", [])
        )
        atmosphere = (
            sp.get("environment", {}).get("atmosphere", "") or
            sp.get("environment", {}).get("style", "") or
            task_data.get("atmosphere", "")
        )
        signature = sp.get("signature_items", [])
        sig_names = [s.get("name", "") for s in signature] if signature else []

        store_info = {
            "name": task_data["store_name"],
            "category": task_data["category"],
            "address": task_data["address"],
            "specialty": list(set(highlights + sig_names)),
            "atmosphere": atmosphere,
        }

        # 增强上下文（Kim K3 总结）
        if context_brief:
            store_info["atmosphere"] = (
                store_info["atmosphere"] + "。补充卖点分析：" + context_brief
            )

        if not DEEPSEEK_API_KEY:
            return self._default_storyboard(
                task_data["store_name"],
                task_data["category"],
                store_info,
            )

        try:
            storyboard = await generate_storyboard(store_info)
            storyboard["_kimi_selling_points"] = sp
            return storyboard
        except Exception as e:
            logger.warning(f"DeepSeek 调用失败，使用模板脚本: {e}")
            return self._default_storyboard(
                task_data["store_name"],
                task_data["category"],
                store_info,
            )

    @staticmethod
    def _default_storyboard(store_name: str, category: str = "美食", store_info: dict = None) -> dict:
        """当 DeepSeek 不可用时的默认分镜模板（可融合 Kimi 卖点）"""
        name = store_name or "宝藏小店"

        # 尝试用 Kimi 卖点个性化
        highlights = []
        atm = ""
        if store_info:
            highlights = store_info.get("specialty", [])
            atm = store_info.get("atmosphere", "")

        hl_text = f"，招牌有{'、'.join(highlights[:3])}" if highlights else ""
        atm_text = f"店内{atm}，" if atm else ""

        return {
            "task_id": "T0000",
            "platform": "douyin",
            "total_duration": 30,
            "scenes": [
                {
                    "scene_no": 1,
                    "duration": 5,
                    "visual": f"{name}门店外观，明亮招牌，温暖的灯光，傍晚时分，电影质感",
                    "narration": f"今天带大家来探一家超棒的{category}店——{name}！{atm_text}超级期待！",
                    "subtitle": f"宝藏探店🔥 {name}",
                },
                {
                    "scene_no": 2,
                    "duration": 6,
                    "visual": f"招牌{highlights[0] if highlights else '菜品'}特写，热气腾腾，诱人色泽，微距景深效果，暖色调",
                    "narration": f"看这个{'招牌' + highlights[0] if highlights else '招牌必点'}，一端上来香味就扑鼻而来{hl_text}！",
                    "subtitle": f"{'招牌必点⭐ ' + highlights[0] if highlights else '招牌必点⭐ 太香了！'}",
                },
                {
                    "scene_no": 3,
                    "duration": 7,
                    "visual": "优雅的就餐环境，温馨装饰细节，柔和灯光氛围，顾客享受美食的中景",
                    "narration": f"环境也超有格调，{atm_text}特别适合约会聚餐～人均还不贵！",
                    "subtitle": "环境绝了😍 人均亲民",
                },
                {
                    "scene_no": 4,
                    "duration": 7,
                    "visual": "美食近景特写，筷子夹起食物，诱人食物质感，慢动作效果",
                    "narration": "一口下去真的太上头了，我一个人能炫三盘！",
                    "subtitle": "太上头了！必打卡⬇️",
                },
                {
                    "scene_no": 5,
                    "duration": 5,
                    "visual": f"{name}门店外景收尾，霓虹灯光，夜晚氛围，地址信息叠印",
                    "narration": "地址我放在简介里了，赶紧收藏起来，周末就来！",
                    "subtitle": "📍地址见简介 快来打卡！",
                },
            ],
            "bgm_suggestion": "轻快美食探店Vlog风格",
            "hashtags": ["#探店", "#宝藏美食", "#本地生活"],
            "_generated_by": "template" + ("+kimi" if highlights else ""),
        }

    async def _step_generate_images(self, storyboard: dict) -> list:
        """步骤 2: 即梦生成关键帧图片"""
        from src.zhitan.services.jimeng_service import generate_image, download_file

        image_paths = []
        for scene in storyboard["scenes"]:
            scene_no = scene["scene_no"]
            visual = scene["visual"]

            prompt = f"竖屏探店视频画面，{visual}，美食探店，高清写实，暖色调，电影质感，1080x1920"

            try:
                result = await generate_image(prompt, width=1080, height=1920)
                img_path = os.path.join(self.images_dir, f"scene_{scene_no:02d}.png")
                await download_file(result["image_url"], img_path)
                image_paths.append(img_path)
            except Exception as e:
                # 降级：生成失败时使用占位图
                image_paths.append(self._create_placeholder(scene_no, visual))

        return image_paths

    async def _step_proofread(self, scenes: list[dict]) -> list[dict]:
        """步骤 3: 文案质检 —— DeepSeek 校对多音字/错别字"""
        from src.zhitan.services.video_pipeline import proofread_script
        return await proofread_script(scenes)

    async def _step_tts(self, scenes: list[dict]) -> list[dict]:
        """步骤 4: 火山方舟 Ark TTS 配音生成

        Returns:
            更新后的分镜列表，含 audio_path / audio_duration
        """
        from src.zhitan.services.tts_service import generate_scene_audios

        return await generate_scene_audios(
            scenes=scenes,
            voice=DEFAULT_VOICE,
            speed=DEFAULT_SPEED,
            output_dir=self.audio_dir,
        )

    async def _step_assemble(
        self,
        storyboard: dict,
        image_paths: list,
    ) -> dict:
        """步骤 5: FFmpeg 全自动剪辑合成（文案质检→TTS→SRT→匹配→合成→多平台→AIGC）

        整合了视频合成、水印、AIGC 标识等所有后处理步骤。

        Returns:
            {platform_id: output_path, ...} 各平台输出文件路径
        """
        from src.zhitan.services.video_pipeline import full_pipeline

        scenes = storyboard["scenes"]
        output_dir = os.path.join(self.task_dir, "output")
        os.makedirs(output_dir, exist_ok=True)

        # 生成 BGM（静默占位轨道）
        bgm_path = os.path.join(self.task_dir, "bgm_silent.mp3")

        result = await full_pipeline(
            scenes=scenes,
            image_paths=image_paths,
            output_dir=output_dir,
            voice=DEFAULT_VOICE,
            speed=DEFAULT_SPEED,
            bgm_path=bgm_path,
            platforms=["douyin", "xiaohongshu", "shipinhao"],
            use_video=False,
        )

        # 保存 SRT 字幕
        if result.get("srt"):
            srt_path = os.path.join(output_dir, "subtitles.srt")
            with open(srt_path, "w", encoding="utf-8") as f:
                f.write(result["srt"])

        # 更新分镜信息（含 TTS 配音路径等）
        storyboard["scenes"] = result.get("scenes", scenes)
        if result.get("srt"):
            storyboard["_srt_subtitles"] = result["srt"]
        storyboard["total_duration"] = result.get("total_duration", 30)

        return result.get("outputs", {})

    async def _step_store(self, outputs: dict) -> dict:
        """步骤 6: 存储成片到静态目录

        Args:
            outputs: {platform_id: output_path, ...}

        Returns:
            {platform_id: static_url, ...}
        """
        dest_dir = "static/demo"
        os.makedirs(dest_dir, exist_ok=True)

        video_urls = {}
        for platform, src_path in outputs.items():
            if platform.startswith("_"):
                continue  # 跳过内部文件（如 _bgm）
            if not os.path.exists(src_path):
                continue

            dest_name = f"video_{self.task_id}_{platform}.mp4"
            dest_path = os.path.join(dest_dir, dest_name)
            shutil.copy2(src_path, dest_path)

            video_urls[platform] = f"/static/demo/{dest_name}"
            logger.info(f"已存储 [{platform}]: {dest_path}")

        return video_urls

    # =============== 辅助方法 ===============

    async def _update_progress(self, progress: int, message: str):
        """更新进度（存入数据库）"""
        async with async_session() as db:
            r = await db.execute(
                select(GenerationTask).where(GenerationTask.id == self.task_id)
            )
            task = r.scalar_one_or_none()
            if task:
                task.status = 1
                task.progress = min(progress, 99)
                await db.commit()

        if self.state_callback:
            try:
                self.state_callback(
                    state="PROGRESS",
                    meta={"progress": progress, "message": message, "task_id": self.task_id},
                )
            except Exception:
                pass

    async def _mark_completed(self, video_urls: dict, storyboard: dict, selling_points: dict = None):
        """标记任务完成"""
        # 将卖点信息合并到分镜脚本中存储
        full_content = dict(storyboard)
        if selling_points:
            full_content["_kimi_analysis"] = selling_points

        async with async_session() as db:
            r = await db.execute(
                select(GenerationTask).where(GenerationTask.id == self.task_id)
            )
            task = r.scalar_one_or_none()
            if task:
                task.status = 2
                task.progress = 100
                task.completed_at = datetime.now()
                task.video_urls = video_urls  # 多平台: {"douyin": "...", "xiaohongshu": "...", "shipinhao": "..."}
                task.script_content = full_content
                await db.commit()

    def mark_failed(self, error_message: str):
        """标记任务失败"""
        import asyncio

        async def _mark():
            async with async_session() as db:
                r = await db.execute(
                    select(GenerationTask).where(GenerationTask.id == self.task_id)
                )
                task = r.scalar_one_or_none()
                if task:
                    task.status = 3
                    task.progress = 0
                    task.error_message = str(error_message)[:500]
                    await db.commit()

        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.ensure_future(_mark())
            else:
                loop.run_until_complete(_mark())
        except Exception:
            pass

    def _create_placeholder(self, scene_no: int, visual: str) -> str:
        """创建占位图片（当 API 调用失败时降级）"""
        import numpy as np
        from PIL import Image, ImageDraw, ImageFont

        # 找中文字体
        font_paths = [
            "C:/Windows/Fonts/msyh.ttc",
            "C:/Windows/Fonts/simhei.ttf",
            "C:/Windows/Fonts/simsun.ttc",
        ]
        font = None
        for fp in font_paths:
            if os.path.exists(fp):
                try:
                    font = ImageFont.truetype(fp, 40)
                    break
                except Exception:
                    pass
        if font is None:
            font = ImageFont.load_default()

        W, H = 1080, 1920
        img = Image.new("RGB", (W, H), color=(30, 30, 50))
        draw = ImageDraw.Draw(img)

        # 场景标题
        draw.text(
            (W // 2 - 200, H // 2 - 100),
            f"场景 {scene_no}",
            fill=(255, 255, 255),
            font=font,
        )
        # 视觉描述（折行）
        desc_lines = [visual[i:i + 20] for i in range(0, len(visual), 20)]
        for j, line in enumerate(desc_lines[:3]):
            draw.text(
                (W // 2 - 250, H // 2 + j * 50),
                line,
                fill=(180, 180, 200),
                font=font,
            )
        draw.rectangle([40, 40, W - 40, H - 40], outline=(80, 80, 120), width=3)

        path = os.path.join(self.images_dir, f"scene_{scene_no:02d}.png")
        img.save(path)
        return path

﻿"""FFmpeg 视频处理服务"""
import os
import subprocess
import asyncio
from loguru import logger
from src.zhitan.config import FFMPEG_PATH, FFPROBE_PATH


class FFmpegService:
    """视频剪辑/转码/水印/多平台适配"""

    @staticmethod
    def get_video_info(filepath: str) -> dict:
        """获取视频信息（时长/分辨率等）"""
        cmd = [
            FFPROBE_PATH, "-v", "quiet", "-print_format", "json",
            "-show_format", "-show_streams", filepath,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            import json
            return json.loads(result.stdout)
        except Exception as e:
            logger.error(f"获取视频信息失败: {e}")
            return {}

    @staticmethod
    def add_watermark(input_path: str, output_path: str, watermark_text: str = "AI辅助制作") -> str:
        """叠加水印到右下角"""
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        cmd = [
            FFMPEG_PATH, "-i", input_path,
            "-vf", (
                f"drawtext=text='{watermark_text}':"
                f"x=w-tw-20:y=h-th-20:"
                f"fontsize=24:fontcolor=white@0.7:"
                f"box=1:boxcolor=black@0.3:boxborderw=5"
            ),
            "-c:a", "copy", "-y", output_path,
        ]
        try:
            subprocess.run(cmd, capture_output=True, text=True, timeout=300, check=True)
            return output_path
        except Exception as e:
            logger.error(f"水印叠加失败: {e}")
            raise

    @staticmethod
    def transcode_for_platform(input_path: str, output_path: str, platform: str) -> str:
        """按平台规格转码"""
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        platform_configs = {
            "douyin": {"width": 1080, "height": 1920, "aspect": "9:16", "fps": 30},
            "xiaohongshu": {"width": 1080, "height": 1080, "aspect": "1:1", "fps": 30},
            "shipinhao": {"width": 1920, "height": 1080, "aspect": "16:9", "fps": 30},
            "kuaishou": {"width": 1080, "height": 1920, "aspect": "9:16", "fps": 30},
        }

        cfg = platform_configs.get(platform, platform_configs["douyin"])
        cmd = [
            FFMPEG_PATH, "-i", input_path,
            "-vf", f"scale={cfg['width']}:{cfg['height']}:force_original_aspect_ratio=decrease,pad={cfg['width']}:{cfg['height']}:(ow-iw)/2:(oh-ih)/2",
            "-r", str(cfg["fps"]),
            "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-c:a", "aac", "-b:a", "128k",
            "-movflags", "+faststart",
            "-y", output_path,
        ]
        try:
            subprocess.run(cmd, capture_output=True, text=True, timeout=300, check=True)
            return output_path
        except Exception as e:
            logger.error(f"转码失败 ({platform}): {e}")
            raise

    @staticmethod
    def composite_video(
        video_clips: list[str],
        audio_path: str,
        subtitle_path: str,
        bgm_path: str,
        output_path: str,
    ) -> str:
        """
        合成最终视频：
        - 拼接多个视频片段
        - 叠加配音
        - 叠加背景音乐（音量降低）
        - 叠加字幕
        """
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        # 简化为直接输出（完整版需要更复杂的滤镜链）
        cmd = [
            FFMPEG_PATH,
            "-i", video_clips[0] if video_clips else "",
            "-i", audio_path,
            "-filter_complex", "[1:a]volume=1.0[voice]",
            "-map", "0:v", "-map", "[voice]",
            "-c:v", "libx264", "-preset", "fast",
            "-c:a", "aac", "-shortest",
            "-y", output_path,
        ]
        try:
            subprocess.run(cmd, capture_output=True, text=True, timeout=300, check=True)
            return output_path
        except Exception as e:
            logger.error(f"视频合成失败: {e}")
            raise

    @staticmethod
    def write_aigc_metadata(input_path: str, output_path: str, metadata: dict = None) -> str:
        """写入隐式AIGC元数据"""
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        if not metadata:
            metadata = {
                "AIGC": "1",
                "AIGC_Tool": "智探AI",
                "AIGC_Time": "",
                "AIGC_Watermark": "AI辅助制作",
            }
        from datetime import datetime
        metadata["AIGC_Time"] = datetime.now().isoformat()

        meta_args = []
        for k, v in metadata.items():
            meta_args.extend(["-metadata", f"{k}={v}"])

        cmd = [
            FFMPEG_PATH, "-i", input_path,
            *meta_args,
            "-c", "copy", "-y", output_path,
        ]
        try:
            subprocess.run(cmd, capture_output=True, text=True, timeout=60, check=True)
            return output_path
        except Exception as e:
            logger.error(f"AIGC元数据写入失败: {e}")
            raise


ffmpeg_service = FFmpegService()

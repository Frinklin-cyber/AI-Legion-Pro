﻿"""风格包路由 - AI出镜人设风格管理"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from src.zhitan.models.database import async_session, StylePack
from src.zhitan.routers.auth import get_current_merchant

router = APIRouter()


# 预设风格包种子数据
import json as _json

PRESET_STYLE_PACKS = [
    {
        "name": "职业探店主理人",
        "description": "专业干练的探店风格，适合高端餐饮和酒店评测",
        "professional_level": 9, "friendly_level": 5, "energy_level": 5,
        "tts_voice_id": "zh_female_professional",
        "suitable_categories": _json.dumps(["高端餐饮", "酒店", "法餐", "日料"], ensure_ascii=False),
        "avatar_url": "",
    },
    {
        "name": "亲和邻家小妹",
        "description": "亲切温暖的邻家风格，适合奶茶、烘焙等年轻化品类",
        "professional_level": 5, "friendly_level": 9, "energy_level": 6,
        "tts_voice_id": "zh_female_friendly",
        "suitable_categories": _json.dumps(["奶茶", "烘焙", "咖啡馆", "甜品"], ensure_ascii=False),
        "avatar_url": "",
    },
    {
        "name": "活力年轻达人",
        "description": "活力四射的年轻风格，适合KTV、剧本杀等娱乐场所",
        "professional_level": 5, "friendly_level": 6, "energy_level": 9,
        "tts_voice_id": "zh_male_energetic",
        "suitable_categories": _json.dumps(["KTV", "剧本杀", "密室逃脱", "景区"], ensure_ascii=False),
        "avatar_url": "",
    },
    {
        "name": "知性文艺青年",
        "description": "文艺知性的慢生活风格，适合书店、咖啡馆等文艺空间",
        "professional_level": 8, "friendly_level": 8, "energy_level": 3,
        "tts_voice_id": "zh_female_artistic",
        "suitable_categories": _json.dumps(["书店", "咖啡馆", "花店", "手作店"], ensure_ascii=False),
        "avatar_url": "",
    },
    {
        "name": "专业美食评论家",
        "description": "专业客观的美食评测风格，适合高端餐厅和私房菜",
        "professional_level": 10, "friendly_level": 3, "energy_level": 5,
        "tts_voice_id": "zh_male_critic",
        "suitable_categories": _json.dumps(["高端餐厅", "私房菜", "牛排馆", "品酒"], ensure_ascii=False),
        "avatar_url": "",
    },
    {
        "name": "热情服务向导",
        "description": "热情好客的服务风格，适合民宿、农家乐等休闲场景",
        "professional_level": 5, "friendly_level": 9, "energy_level": 8,
        "tts_voice_id": "zh_female_warm",
        "suitable_categories": _json.dumps(["民宿", "农家乐", "度假村", "温泉"], ensure_ascii=False),
        "avatar_url": "",
    },
]


async def ensure_preset_style_packs():
    """确保预设风格包已写入数据库"""
    async with async_session() as db:
        r = await db.execute(select(StylePack).limit(1))
        if r.scalar_one_or_none():
            return
        for sp in PRESET_STYLE_PACKS:
            db.add(StylePack(**sp))
        await db.commit()


@router.get("")
async def list_style_packs(merchant: dict = Depends(get_current_merchant)):
    """风格包列表"""
    await ensure_preset_style_packs()
    async with async_session() as db:
        r = await db.execute(
            select(StylePack).where(StylePack.is_active == True).order_by(StylePack.id)
        )
        packs = r.scalars().all()
        return {
            "status": "success",
            "style_packs": [
                {
                    "id": sp.id,
                    "name": sp.name,
                    "description": sp.description,
                    "professional_level": sp.professional_level,
                    "friendly_level": sp.friendly_level,
                    "energy_level": sp.energy_level,
                    "sample_video_url": sp.sample_video_url,
                    "tts_voice_id": sp.tts_voice_id,
                    "suitable_categories": sp.suitable_categories,
                    "avatar_url": sp.avatar_url,
                }
                for sp in packs
            ],
        }


@router.get("/{pack_id}")
async def get_style_pack(pack_id: int, merchant: dict = Depends(get_current_merchant)):
    """风格包详情"""
    async with async_session() as db:
        r = await db.execute(select(StylePack).where(StylePack.id == pack_id))
        sp = r.scalar_one_or_none()
        if not sp:
            raise HTTPException(404, "风格包不存在")
        return {
            "status": "success",
            "style_pack": {
                "id": sp.id,
                "name": sp.name,
                "description": sp.description,
                "professional_level": sp.professional_level,
                "friendly_level": sp.friendly_level,
                "energy_level": sp.energy_level,
                "sample_video_url": sp.sample_video_url,
                "tts_voice_id": sp.tts_voice_id,
                "suitable_categories": sp.suitable_categories,
                "avatar_url": sp.avatar_url,
                "preset_params": sp.preset_params,
            },
        }

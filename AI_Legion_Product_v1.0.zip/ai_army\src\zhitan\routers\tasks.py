﻿"""生成任务路由 - 创建任务、查看进度、下载成片"""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select, and_

from src.zhitan.models.database import async_session, GenerationTask, Store, MerchantQuota, StylePack
from src.zhitan.routers.auth import get_current_merchant
from src.zhitan.celery_app import run_pipeline

router = APIRouter()


class TaskCreateRequest(BaseModel):
    store_id: int = Field(...)
    style_pack_id: int = Field(...)
    material_ids: list[int] = Field(..., min_length=1)
    platform_targets: list[str] = Field(default=["douyin"])
    interview_storyboard: Optional[dict] = Field(default=None)  # 来自采访生成的剧本


@router.get("")
async def list_tasks(
    status: Optional[int] = Query(None),
    merchant: dict = Depends(get_current_merchant),
):
    """任务列表"""
    async with async_session() as db:
        query = select(GenerationTask).where(
            GenerationTask.merchant_id == merchant["merchant_id"]
        )
        if status is not None:
            query = query.where(GenerationTask.status == status)
        query = query.order_by(GenerationTask.created_at.desc())

        r = await db.execute(query)
        tasks = r.scalars().all()
        return {
            "status": "success",
            "tasks": [
                {
                    "id": t.id,
                    "store_id": t.store_id,
                    "style_pack_id": t.style_pack_id,
                    "material_ids": t.material_ids,
                    "platform_targets": t.platform_targets,
                    "status": t.status,
                    "progress": t.progress,
                    "script_content": t.script_content,
                    "video_urls": t.video_urls,
                    "thumbnail_url": t.thumbnail_url,
                    "error_message": t.error_message,
                    "paid_amount": t.paid_amount,
                    "created_at": t.created_at.isoformat() if t.created_at else None,
                    "completed_at": t.completed_at.isoformat() if t.completed_at else None,
                }
                for t in tasks
            ],
        }


@router.post("")
async def create_task(req: TaskCreateRequest, merchant: dict = Depends(get_current_merchant)):
    """创建生成任务 → 入队 Celery 异步流水线"""
    async with async_session() as db:
        # 校验门店归属
        r = await db.execute(
            select(Store).where(
                Store.id == req.store_id,
                Store.merchant_id == merchant["merchant_id"],
            )
        )
        store = r.scalar_one_or_none()
        if not store:
            raise HTTPException(403, "门店不存在或无权操作")

        # 校验风格包存在
        r2 = await db.execute(select(StylePack).where(StylePack.id == req.style_pack_id))
        if not r2.scalar_one_or_none():
            raise HTTPException(400, "风格包不存在")

        # 检查套餐余量（不存在时自动创建体验套餐）
        r3 = await db.execute(
            select(MerchantQuota).where(
                MerchantQuota.merchant_id == merchant["merchant_id"]
            )
        )
        quota = r3.scalar_one_or_none()

        from datetime import datetime, date

        if not quota:
            # 首次使用，自动赠送体验套餐
            quota = MerchantQuota(
                merchant_id=merchant["merchant_id"],
                plan_type="experience",
                remaining_count=3,  # 赠送3次免费额度
                expire_at=None,
            )
            db.add(quota)

        if quota.remaining_count <= 0:
            raise HTTPException(400, "套餐余量不足，请先购买套餐")

        if quota.expire_at and quota.expire_at < date.today():
            raise HTTPException(400, "套餐已过期，请续费")

        # 扣减余量
        quota.remaining_count -= 1

        # 创建任务
        task = GenerationTask(
            merchant_id=merchant["merchant_id"],
            store_id=req.store_id,
            style_pack_id=req.style_pack_id,
            material_ids=req.material_ids,
            platform_targets=req.platform_targets,
            status=0,
            progress=0,
            paid_amount=9.9,
            script_content=req.interview_storyboard or None,  # 采访剧本预填充
        )
        db.add(task)
        await db.commit()
        await db.refresh(task)

        # 入队 Celery 异步任务
        celery_result = run_pipeline.delay(task.id)
        # 将 celery task id 存入数据库备查
        task.coze_workflow_id = celery_result.id
        await db.commit()

        return {
            "status": "success",
            "task_id": task.id,
            "celery_task_id": celery_result.id,
        }


@router.get("/{task_id}")
async def get_task(task_id: int, merchant: dict = Depends(get_current_merchant)):
    """任务详情（含进度）"""
    async with async_session() as db:
        r = await db.execute(
            select(GenerationTask).where(
                and_(
                    GenerationTask.id == task_id,
                    GenerationTask.merchant_id == merchant["merchant_id"],
                )
            )
        )
        task = r.scalar_one_or_none()
        if not task:
            raise HTTPException(404, "任务不存在")

        return {
            "status": "success",
            "task": {
                "id": task.id,
                "store_id": task.store_id,
                "style_pack_id": task.style_pack_id,
                "material_ids": task.material_ids,
                "platform_targets": task.platform_targets,
                "status": task.status,
                "progress": task.progress,
                "script_content": task.script_content,
                "video_urls": task.video_urls,
                "thumbnail_url": task.thumbnail_url,
                "error_message": task.error_message,
                "created_at": task.created_at.isoformat() if task.created_at else None,
                "completed_at": task.completed_at.isoformat() if task.completed_at else None,
            },
        }


@router.get("/{task_id}/video")
async def get_task_video(task_id: int, merchant: dict = Depends(get_current_merchant)):
    """获取成片下载URL"""
    async with async_session() as db:
        r = await db.execute(
            select(GenerationTask).where(
                and_(
                    GenerationTask.id == task_id,
                    GenerationTask.merchant_id == merchant["merchant_id"],
                )
            )
        )
        task = r.scalar_one_or_none()
        if not task:
            raise HTTPException(404, "任务不存在")
        if task.status != 2:
            raise HTTPException(400, "任务尚未完成")
        return {"status": "success", "video_urls": task.video_urls or {}}


@router.post("/{task_id}/regenerate")
async def regenerate_task(task_id: int, merchant: dict = Depends(get_current_merchant)):
    """重新生成"""
    async with async_session() as db:
        r = await db.execute(
            select(GenerationTask).where(
                and_(
                    GenerationTask.id == task_id,
                    GenerationTask.merchant_id == merchant["merchant_id"],
                )
            )
        )
        task = r.scalar_one_or_none()
        if not task:
            raise HTTPException(404, "任务不存在")

        task.status = 0
        task.progress = 0
        task.video_urls = None
        task.error_message = None
        task.completed_at = None
        await db.commit()

        # 重新入队 Celery
        celery_result = run_pipeline.delay(task.id)
        task.coze_workflow_id = celery_result.id
        await db.commit()

        return {"status": "success", "message": "已重新提交"}

﻿"""认证路由 - 短信登录、资质上传、协议签署"""
import random
import string
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Header, Request
from pydantic import BaseModel, Field
from sqlalchemy import select

from src.zhitan.models.database import async_session, Merchant, Agreement, SmsCode
from src.zhitan.config import JWT_SECRET_KEY, JWT_ALGORITHM, JWT_EXPIRE_DAYS, SMS_PROVIDER

router = APIRouter()


# ====== 数据模型 ======
class SmsSendRequest(BaseModel):
    phone: str = Field(..., pattern=r"^1[3-9]\d{9}$")

class SmsVerifyRequest(BaseModel):
    phone: str = Field(..., pattern=r"^1[3-9]\d{9}$")
    code: str = Field(..., min_length=4, max_length=6)

class QualificationRequest(BaseModel):
    company_name: Optional[str] = None
    credit_code: Optional[str] = None
    business_license_url: Optional[str] = None
    food_license_url: Optional[str] = None

class AgreementSignRequest(BaseModel):
    agreement_type: str = Field(..., pattern=r"^(material_authorization|ai_disclosure)$")


# ====== JWT 工具 ======
def create_token(merchant_id: int, phone: str, company_name: str = "") -> str:
    import jwt
    now = datetime.now(timezone.utc)
    payload = {
        "merchant_id": merchant_id,
        "phone": phone,
        "company_name": company_name,
        "iat": now,
        "exp": now + timedelta(days=JWT_EXPIRE_DAYS),
    }
    return jwt.encode(payload, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)


def verify_token(token: str) -> Optional[dict]:
    import jwt
    try:
        return jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
    except Exception:
        return None


async def get_current_merchant(authorization: str = Header(None)) -> dict:
    """从Authorization头获取当前商家信息"""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "未登录")
    payload = verify_token(authorization.split(" ", 1)[1])
    if not payload:
        raise HTTPException(401, "登录已过期")
    return payload


# ====== 接口实现 ======
@router.post("/sms/send")
async def sms_send(req: SmsSendRequest, request: Request):
    """发送验证码（开发环境用mock）"""
    code = "".join(random.choices(string.digits, k=6))
    expires_at = datetime.now() + timedelta(minutes=5)

    async with async_session() as db:
        sms = SmsCode(phone=req.phone, code=code, expires_at=expires_at)
        db.add(sms)
        await db.commit()

    if SMS_PROVIDER == "mock":
        return {"status": "success", "message": "验证码已发送", "debug_code": code}
    # TODO: 接入真实短信服务
    return {"status": "success", "message": "验证码已发送"}


@router.post("/sms/verify")
async def sms_verify(req: SmsVerifyRequest):
    """验证码登录"""
    async with async_session() as db:
        # 验证码校验
        r = await db.execute(
            select(SmsCode).where(
                SmsCode.phone == req.phone,
                SmsCode.code == req.code,
                SmsCode.used == False,
                SmsCode.expires_at > datetime.now(),
            ).order_by(SmsCode.created_at.desc()).limit(1)
        )
        sms = r.scalar_one_or_none()
        if not sms:
            raise HTTPException(400, "验证码错误或已过期")

        sms.used = True

        # 查找或创建商家
        r2 = await db.execute(select(Merchant).where(Merchant.phone == req.phone))
        merchant = r2.scalar_one_or_none()
        if not merchant:
            merchant = Merchant(phone=req.phone, status=0)
            db.add(merchant)
            await db.flush()

        await db.commit()

        token = create_token(merchant.id, merchant.phone, merchant.company_name or "")
        return {
            "status": "success",
            "token": token,
            "merchant_id": merchant.id,
            "is_new": merchant.status == 0,
            "company_name": merchant.company_name,
        }


@router.get("/profile")
async def get_profile(merchant: dict = Depends(get_current_merchant)):
    """获取商家信息"""
    async with async_session() as db:
        r = await db.execute(select(Merchant).where(Merchant.id == merchant["merchant_id"]))
        m = r.scalar_one_or_none()
        if not m:
            raise HTTPException(404, "商家不存在")

        # 检查协议签署状态
        r2 = await db.execute(
            select(Agreement).where(Agreement.merchant_id == m.id).order_by(Agreement.signed_at.desc())
        )
        agreements = r2.scalars().all()
        signed_types = {a.agreement_type for a in agreements}

        return {
            "status": "success",
            "profile": {
                "id": m.id,
                "phone": m.phone,
                "company_name": m.company_name,
                "credit_code": m.credit_code,
                "business_license_url": m.business_license_url,
                "food_license_url": m.food_license_url,
                "status": m.status,
                "created_at": m.created_at.isoformat() if m.created_at else None,
            },
            "agreements": {
                "material_authorization": "material_authorization" in signed_types,
                "ai_disclosure": "ai_disclosure" in signed_types,
            },
        }


@router.put("/profile")
async def update_profile(req: QualificationRequest, merchant: dict = Depends(get_current_merchant)):
    """更新商家信息"""
    async with async_session() as db:
        r = await db.execute(select(Merchant).where(Merchant.id == merchant["merchant_id"]))
        m = r.scalar_one_or_none()
        if not m:
            raise HTTPException(404, "商家不存在")

        if req.company_name is not None:
            m.company_name = req.company_name
        if req.credit_code is not None:
            m.credit_code = req.credit_code
        if req.business_license_url is not None:
            m.business_license_url = req.business_license_url
        if req.food_license_url is not None:
            m.food_license_url = req.food_license_url

        await db.commit()
        return {"status": "success"}


@router.post("/qualification")
async def upload_qualification(req: QualificationRequest, merchant: dict = Depends(get_current_merchant)):
    """上传资质"""
    async with async_session() as db:
        r = await db.execute(select(Merchant).where(Merchant.id == merchant["merchant_id"]))
        m = r.scalar_one_or_none()
        if not m:
            raise HTTPException(404, "商家不存在")

        if req.business_license_url:
            m.business_license_url = req.business_license_url
        if req.food_license_url:
            m.food_license_url = req.food_license_url
        m.company_name = m.company_name or req.company_name
        m.credit_code = m.credit_code or req.credit_code
        m.status = 1  # 自动认证（MVP简化，正式环境需人工审核）

        await db.commit()
        return {"status": "success", "message": "资质已提交"}


@router.post("/agreement/sign")
async def sign_agreement(req: AgreementSignRequest, request: Request, merchant: dict = Depends(get_current_merchant)):
    """签署协议（素材授权 / AI标识知情书）"""
    async with async_session() as db:
        agreement = Agreement(
            merchant_id=merchant["merchant_id"],
            agreement_type=req.agreement_type,
            ip_address=request.client.host if request.client else "unknown",
            user_agent=request.headers.get("user-agent", ""),
        )
        db.add(agreement)
        await db.commit()
        return {"status": "success", "message": f"协议 {req.agreement_type} 已签署"}

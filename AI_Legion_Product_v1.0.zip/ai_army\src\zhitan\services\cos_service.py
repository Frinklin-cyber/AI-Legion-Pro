﻿"""腾讯云 COS 对象存储服务"""
import os
from loguru import logger
from src.zhitan.config import COS_SECRET_ID, COS_SECRET_KEY, COS_BUCKET, COS_REGION


class COSService:
    """素材/成片/缩略图存储"""

    def __init__(self):
        self.enabled = bool(COS_SECRET_ID and COS_SECRET_KEY)
        if self.enabled:
            try:
                from qcloud_cos import CosConfig, CosS3Client
                config = CosConfig(Region=COS_REGION, SecretId=COS_SECRET_ID, SecretKey=COS_SECRET_KEY)
                self.client = CosS3Client(config)
                logger.info("COS 客户端已就绪")
            except Exception as e:
                logger.warning(f"COS 初始化失败，回退到本地存储: {e}")
                self.enabled = False

    def upload_file(self, local_path: str, cos_key: str) -> str:
        """上传文件到COS，返回URL"""
        if not self.enabled:
            logger.warning("COS 未配置，使用本地路径")
            return f"/static/{cos_key}"

        try:
            self.client.upload_file(
                Bucket=COS_BUCKET,
                LocalFilePath=local_path,
                Key=cos_key,
            )
            url = f"https://{COS_BUCKET}.cos.{COS_REGION}.myqcloud.com/{cos_key}"
            logger.info(f"上传成功: {cos_key}")
            return url
        except Exception as e:
            logger.error(f"COS上传失败: {e}")
            return f"/static/{cos_key}"

    def generate_presigned_url(self, cos_key: str, expires: int = 3600) -> dict:
        """生成预签名上传URL"""
        if not self.enabled:
            return {"url": f"/api/v1/materials/upload", "fields": {}}

        try:
            url = self.client.get_presigned_upload_url(
                Bucket=COS_BUCKET,
                Key=cos_key,
                Expired=expires,
            )
            return {"url": url, "fields": {}}
        except Exception as e:
            logger.error(f"生成签名URL失败: {e}")
            raise


cos_service = COSService()

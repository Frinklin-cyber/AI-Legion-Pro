﻿"""即梦（Jimeng）API 服务 - 火山引擎签名 + 图片/视频生成

接口：https://visual.volcengineapi.com
Action：CVSync2AsyncSubmitTask（提交）/ CVSync2AsyncGetResult（查询）
"""

import hashlib
import hmac
import json
import os
import time
from datetime import datetime, timezone
from urllib.parse import quote
from typing import Optional

import httpx

from src.zhitan.config import (
    JIMENG_ACCESS_KEY_ID,
    JIMENG_SECRET_ACCESS_KEY,
    JIMENG_REGION,
    JIMENG_SERVICE,
)

JIMENG_HOST = "visual.volcengineapi.com"
JIMENG_URL = f"https://{JIMENG_HOST}/"
POLL_INTERVAL = 3  # 轮询间隔（秒）
MAX_POLL_COUNT = 60  # 最大轮询次数（3分钟）


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _hmac_sha256(key: bytes, msg: str) -> bytes:
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def _sign_volcengine(method: str, body: str) -> dict:
    """生成火山引擎 API 签名（Signature V4）"""
    if not JIMENG_ACCESS_KEY_ID or not JIMENG_SECRET_ACCESS_KEY:
        raise RuntimeError("Jimeng 凭证未配置，请在 .env 中设置 JIMENG_ACCESS_KEY_ID / JIMENG_SECRET_ACCESS_KEY")

    now = datetime.now(timezone.utc)
    x_date = now.strftime("%Y%m%dT%H%M%SZ")
    date_short = now.strftime("%Y%m%d")

    # 1. Canonical Request
    canonical_uri = "/"
    canonical_querystring = ""
    content_type = "application/json"
    payload_hash = _sha256(body.encode("utf-8"))
    canonical_headers = (
        f"content-type:{content_type}\n"
        f"host:{JIMENG_HOST}\n"
        f"x-date:{x_date}\n"
    )
    signed_headers = "content-type;host;x-date"
    canonical_request = (
        f"{method}\n"
        f"{canonical_uri}\n"
        f"{canonical_querystring}\n"
        f"{canonical_headers}\n"
        f"{signed_headers}\n"
        f"{payload_hash}"
    )

    # 2. String to Sign
    algorithm = "HMAC-SHA256"
    credential_scope = f"{date_short}/{JIMENG_REGION}/{JIMENG_SERVICE}/request"
    string_to_sign = (
        f"{algorithm}\n"
        f"{x_date}\n"
        f"{credential_scope}\n"
        f"{_sha256(canonical_request.encode('utf-8'))}"
    )

    # 3. Signing Key
    k_date = _hmac_sha256(JIMENG_SECRET_ACCESS_KEY.encode("utf-8"), date_short)
    k_region = _hmac_sha256(k_date, JIMENG_REGION)
    k_service = _hmac_sha256(k_region, JIMENG_SERVICE)
    k_signing = _hmac_sha256(k_service, "request")
    signature = hmac.new(k_signing, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

    # 4. Authorization Header
    authorization = (
        f"{algorithm} Credential={JIMENG_ACCESS_KEY_ID}/{credential_scope}, "
        f"SignedHeaders={signed_headers}, Signature={signature}"
    )

    return {
        "Authorization": authorization,
        "Content-Type": content_type,
        "Host": JIMENG_HOST,
        "X-Date": x_date,
    }


async def _call_visual_api(action: str, body: dict, timeout: int = 120) -> dict:
    """通用火山引擎视觉 API 调用"""
    body_str = json.dumps(body, ensure_ascii=False)
    headers = _sign_volcengine("POST", body_str)

    # Action + Version 作为 QueryString
    params = {
        "Action": action,
        "Version": "2022-08-31",
    }

    async with httpx.AsyncClient(timeout=timeout) as client:
        r = await client.post(JIMENG_URL, params=params, headers=headers, content=body_str)

    if r.status_code != 200:
        try:
            detail = r.json()
        except Exception:
            detail = r.text[:500]
        raise RuntimeError(f"即梦 API 调用失败 [{r.status_code}]: {detail}")

    data = r.json()
    if data.get("ResponseMetadata", {}).get("Error"):
        err = data["ResponseMetadata"]["Error"]
        raise RuntimeError(f"即梦 API 错误 [{err.get('Code')}]: {err.get('Message')}")

    return data


async def _submit_and_wait(body: dict, timeout: int = 300) -> dict:
    """提交异步任务并轮询等待完成"""
    # 1. 提交任务
    submit_resp = await _call_visual_api("CVSync2AsyncSubmitTask", body)
    result = submit_resp.get("Result", submit_resp)
    task_id = result.get("task_id")
    if not task_id:
        raise RuntimeError(f"提交任务失败，未获得 task_id:\n{json.dumps(submit_resp, ensure_ascii=False)[:500]}")

    # 2. 轮询结果
    for attempt in range(MAX_POLL_COUNT):
        time.sleep(POLL_INTERVAL)
        query_body = {
            "req_key": body.get("req_key"),
            "task_id": task_id,
        }
        try:
            query_resp = await _call_visual_api("CVSync2AsyncGetResult", query_body)
        except RuntimeError:
            continue

        query_result = query_resp.get("Result", query_resp)
        status = query_result.get("status") or query_result.get("code")

        if status in ("done", "success", 1, "1"):
            return query_result
        elif status in ("failed", "error", -1, "-1"):
            err_msg = query_result.get("message", "未知错误")
            raise RuntimeError(f"即梦任务失败 [{task_id}]: {err_msg}")

    raise TimeoutError(f"即梦任务超时 [{task_id}]，已轮询 {MAX_POLL_COUNT} 次")


async def generate_image(
    prompt: str,
    width: int = 1080,
    height: int = 1920,
    negative_prompt: str = "",
    seed: int = -1,
) -> dict:
    """文生图 - 即梦 t2i v4.0

    Returns:
        {"task_id": "...", "image_url": "https://..."}
    """
    body = {
        "req_key": "jimeng_t2i_v40",
        "prompt": prompt,
        "width": width,
        "height": height,
        "seed": seed,
        "return_url": True,
    }
    if negative_prompt:
        body["negative_prompt"] = negative_prompt

    result = await _submit_and_wait(body)
    image_url = result.get("data", {}).get("image_urls", [None])[0] or result.get("image_url")

    if not image_url:
        raise RuntimeError(f"即梦图片生成成功但未返回 image_url:\n{json.dumps(result, ensure_ascii=False)[:500]}")

    return {"task_id": result.get("task_id", ""), "image_url": image_url}


async def generate_video_from_image(
    image_url: str,
    prompt: str = "",
    fps: int = 24,
    duration: int = 5,
    seed: int = -1,
) -> dict:
    """图生视频 - 即梦 ti2v（首帧图驱动）

    Returns:
        {"task_id": "...", "video_url": "https://..."}
    """
    body = {
        "req_key": "jimeng_ti2v_v30_pro",
        "image_url": image_url,
        "prompt": prompt or "smooth cinematic motion, slow camera movement",
        "fps": fps,
        "duration": duration,
        "seed": seed,
        "return_url": True,
    }

    result = await _submit_and_wait(body, timeout=300)
    video_url = result.get("data", {}).get("video_urls", [None])[0] or result.get("video_url")

    if not video_url:
        raise RuntimeError(f"即梦视频生成成功但未返回 video_url:\n{json.dumps(result, ensure_ascii=False)[:500]}")

    return {"task_id": result.get("task_id", ""), "video_url": video_url}


async def download_file(url: str, dest_path: str) -> str:
    """下载文件到本地"""
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    async with httpx.AsyncClient(timeout=120, follow_redirects=True) as client:
        r = await client.get(url)
        if r.status_code != 200:
            raise RuntimeError(f"下载失败 [{r.status_code}]: {url}")
        with open(dest_path, "wb") as f:
            f.write(r.content)
    return dest_path

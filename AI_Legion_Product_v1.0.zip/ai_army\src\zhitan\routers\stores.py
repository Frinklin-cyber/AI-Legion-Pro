﻿"""门店管理路由"""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select, func

from src.zhitan.models.database import async_session, Store
from src.zhitan.routers.auth import get_current_merchant

router = APIRouter()


class StoreCreateRequest(BaseModel):
    store_name: str = Field(..., min_length=1, max_length=200)
    category: Optional[str] = Field(None, max_length=50)
    address: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    avg_price: Optional[float] = None
    signature_dishes: Optional[list] = None
    selling_points: Optional[list] = None
    description: Optional[str] = None


class StoreUpdateRequest(BaseModel):
    store_name: Optional[str] = Field(None, min_length=1, max_length=200)
    category: Optional[str] = Field(None, max_length=50)
    address: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    avg_price: Optional[float] = None
    signature_dishes: Optional[list] = None
    selling_points: Optional[list] = None
    description: Optional[str] = None


@router.get("")
async def list_stores(merchant: dict = Depends(get_current_merchant)):
    """门店列表"""
    async with async_session() as db:
        r = await db.execute(
            select(Store).where(Store.merchant_id == merchant["merchant_id"]).order_by(Store.created_at.desc())
        )
        stores = r.scalars().all()
        return {
            "status": "success",
            "stores": [
                {
                    "id": s.id,
                    "store_name": s.store_name,
                    "category": s.category,
                    "address": s.address,
                    "latitude": s.latitude,
                    "longitude": s.longitude,
                    "avg_price": s.avg_price,
                    "signature_dishes": s.signature_dishes,
                    "selling_points": s.selling_points,
                    "description": s.description,
                    "status": s.status,
                    "created_at": s.created_at.isoformat() if s.created_at else None,
                }
                for s in stores
            ],
        }


@router.post("")
async def create_store(req: StoreCreateRequest, merchant: dict = Depends(get_current_merchant)):
    """新增门店"""
    async with async_session() as db:
        store = Store(
            merchant_id=merchant["merchant_id"],
            store_name=req.store_name,
            category=req.category,
            address=req.address,
            latitude=req.latitude,
            longitude=req.longitude,
            avg_price=req.avg_price,
            signature_dishes=req.signature_dishes,
            selling_points=req.selling_points,
            description=req.description,
        )
        db.add(store)
        await db.commit()
        await db.refresh(store)
        return {"status": "success", "store_id": store.id}


@router.put("/{store_id}")
async def update_store(store_id: int, req: StoreUpdateRequest, merchant: dict = Depends(get_current_merchant)):
    """编辑门店"""
    async with async_session() as db:
        r = await db.execute(
            select(Store).where(Store.id == store_id, Store.merchant_id == merchant["merchant_id"])
        )
        store = r.scalar_one_or_none()
        if not store:
            raise HTTPException(404, "门店不存在")

        update_data = req.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(store, key, value)

        await db.commit()
        return {"status": "success"}


@router.delete("/{store_id}")
async def delete_store(store_id: int, merchant: dict = Depends(get_current_merchant)):
    """删除门店"""
    async with async_session() as db:
        r = await db.execute(
            select(Store).where(Store.id == store_id, Store.merchant_id == merchant["merchant_id"])
        )
        store = r.scalar_one_or_none()
        if not store:
            raise HTTPException(404, "门店不存在")
        await db.delete(store)
        await db.commit()
        return {"status": "success"}

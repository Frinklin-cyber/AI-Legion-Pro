﻿"""数据库模型定义（SQLAlchemy + PostgreSQL）"""
from datetime import datetime, date
from decimal import Decimal
from typing import Optional, AsyncGenerator

from sqlalchemy import (
    create_engine, Column, BigInteger, String, Text, Integer, SmallInteger,
    Float, Boolean, Date, DateTime, ForeignKey, func, JSON
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker

from src.zhitan.config import DATABASE_URL, SYNC_DATABASE_URL


class Base(DeclarativeBase):
    pass


_is_sqlite = DATABASE_URL.startswith("sqlite")
# SQLite用Integer（自适应64位），PostgreSQL用BigInteger（匹配BIGSERIAL）
_PK = Integer if _is_sqlite else BigInteger
async_engine = create_async_engine(
    DATABASE_URL, echo=False,
    **({} if _is_sqlite else {"pool_size": 20, "max_overflow": 40})
)
sync_engine = create_engine(SYNC_DATABASE_URL, echo=False)

async_session_factory = async_sessionmaker(async_engine, class_=AsyncSession, expire_on_commit=False)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_factory() as session:
        try:
            yield session
        finally:
            await session.close()


async_session = async_session_factory


# ==================== 商家表 ====================
class Merchant(Base):
    __tablename__ = "merchants"

    id: Mapped[int] = mapped_column(_PK, primary_key=True)
    phone: Mapped[str] = mapped_column(String(20), unique=True, nullable=False, index=True)
    company_name: Mapped[Optional[str]] = mapped_column(String(200))
    credit_code: Mapped[Optional[str]] = mapped_column(String(50))
    business_license_url: Mapped[Optional[str]] = mapped_column(Text)
    food_license_url: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[int] = mapped_column(SmallInteger, default=0, comment="0待认证 1已认证 2驳回")
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    stores = relationship("Store", back_populates="merchant")
    tasks = relationship("GenerationTask", back_populates="merchant")
    orders = relationship("Order", back_populates="merchant")
    quota = relationship("MerchantQuota", back_populates="merchant", uselist=False)


# ==================== 门店表 ====================
class Store(Base):
    __tablename__ = "stores"

    id: Mapped[int] = mapped_column(_PK, primary_key=True)
    merchant_id: Mapped[int] = mapped_column(_PK, ForeignKey("merchants.id"), nullable=False, index=True)
    store_name: Mapped[str] = mapped_column(String(200), nullable=False)
    category: Mapped[Optional[str]] = mapped_column(String(50))
    address: Mapped[Optional[str]] = mapped_column(Text)
    latitude: Mapped[Optional[float]] = mapped_column(Float)
    longitude: Mapped[Optional[float]] = mapped_column(Float)
    avg_price: Mapped[Optional[float]] = mapped_column(Float)
    signature_dishes: Mapped[Optional[dict]] = mapped_column(JSON)
    selling_points: Mapped[Optional[dict]] = mapped_column(JSON)
    description: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[int] = mapped_column(SmallInteger, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    merchant = relationship("Merchant", back_populates="stores")
    materials = relationship("Material", back_populates="store")


# ==================== 素材表 ====================
class Material(Base):
    __tablename__ = "materials"

    id: Mapped[int] = mapped_column(_PK, primary_key=True)
    store_id: Mapped[int] = mapped_column(_PK, ForeignKey("stores.id"), nullable=False, index=True)
    file_url: Mapped[str] = mapped_column(Text, nullable=False)
    file_type: Mapped[int] = mapped_column(SmallInteger, comment="1视频 2图片")
    duration: Mapped[Optional[int]] = mapped_column(Integer, comment="视频时长(秒)")
    file_size: Mapped[Optional[int]] = mapped_column(_PK)
    width: Mapped[Optional[int]] = mapped_column(Integer)
    height: Mapped[Optional[int]] = mapped_column(Integer)
    thumbnail_url: Mapped[Optional[str]] = mapped_column(Text)
    used_count: Mapped[int] = mapped_column(Integer, default=0)
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    store = relationship("Store", back_populates="materials")


# ==================== 风格包表 ====================
class StylePack(Base):
    __tablename__ = "style_packs"

    id: Mapped[int] = mapped_column(_PK, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    professional_level: Mapped[int] = mapped_column(SmallInteger, comment="专业度 1-10")
    friendly_level: Mapped[int] = mapped_column(SmallInteger, comment="亲和力 1-10")
    energy_level: Mapped[int] = mapped_column(SmallInteger, comment="活力值 1-10")
    sample_video_url: Mapped[Optional[str]] = mapped_column(Text)
    tts_voice_id: Mapped[Optional[str]] = mapped_column(String(50))
    suitable_categories: Mapped[Optional[dict]] = mapped_column(JSON)
    avatar_url: Mapped[Optional[str]] = mapped_column(Text, comment="AI出镜形象预览图")
    preset_params: Mapped[Optional[dict]] = mapped_column(JSON, comment="参数预设JSON")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


# ==================== 生成任务表 ====================
class GenerationTask(Base):
    __tablename__ = "generation_tasks"

    id: Mapped[int] = mapped_column(_PK, primary_key=True)
    merchant_id: Mapped[int] = mapped_column(_PK, ForeignKey("merchants.id"), nullable=False, index=True)
    store_id: Mapped[int] = mapped_column(_PK, ForeignKey("stores.id"), nullable=False)
    style_pack_id: Mapped[int] = mapped_column(_PK, ForeignKey("style_packs.id"), nullable=False)
    material_ids: Mapped[Optional[list]] = mapped_column(JSON)
    platform_targets: Mapped[list] = mapped_column(JSON, comment='["douyin"] 本期仅抖音')
    status: Mapped[int] = mapped_column(SmallInteger, default=0, comment="0排队 1生成中 2完成 3失败")
    progress: Mapped[int] = mapped_column(SmallInteger, default=0, comment="进度 0-100")
    script_content: Mapped[Optional[dict]] = mapped_column(JSON, comment="DeepSeek生成的分镜脚本")
    video_urls: Mapped[Optional[dict]] = mapped_column(JSON, comment='{"douyin":"url"}')
    thumbnail_url: Mapped[Optional[str]] = mapped_column(Text)
    error_message: Mapped[Optional[str]] = mapped_column(Text)
    paid_amount: Mapped[Optional[float]] = mapped_column(Float)
    coze_workflow_id: Mapped[Optional[str]] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    merchant = relationship("Merchant", back_populates="tasks")
    store = relationship("Store")
    style_pack = relationship("StylePack")


# ==================== 订单/支付表 ====================
class Order(Base):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(_PK, primary_key=True)
    merchant_id: Mapped[int] = mapped_column(_PK, ForeignKey("merchants.id"), nullable=False, index=True)
    order_no: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    order_type: Mapped[int] = mapped_column(SmallInteger, comment="1单条 2套餐")
    plan_name: Mapped[Optional[str]] = mapped_column(String(100))
    amount: Mapped[float] = mapped_column(Float)
    status: Mapped[int] = mapped_column(SmallInteger, default=0, comment="0待支付 1已支付 2退款")
    payment_method: Mapped[Optional[str]] = mapped_column(String(20))
    paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    merchant = relationship("Merchant", back_populates="orders")


# ==================== 套餐余量表 ====================
class MerchantQuota(Base):
    __tablename__ = "merchant_quota"

    id: Mapped[int] = mapped_column(_PK, primary_key=True)
    merchant_id: Mapped[int] = mapped_column(_PK, ForeignKey("merchants.id"), unique=True, nullable=False)
    plan_type: Mapped[Optional[str]] = mapped_column(String(20), comment="experience/standard/flagship")
    remaining_count: Mapped[int] = mapped_column(Integer, default=0)
    expire_at: Mapped[Optional[date]] = mapped_column(Date)
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())

    merchant = relationship("Merchant", back_populates="quota")


# ==================== 协议签署表 ====================
class Agreement(Base):
    __tablename__ = "agreements"

    id: Mapped[int] = mapped_column(_PK, primary_key=True)
    merchant_id: Mapped[int] = mapped_column(_PK, ForeignKey("merchants.id"), nullable=False)
    agreement_type: Mapped[str] = mapped_column(String(50), comment="material_authorization/ai_disclosure")
    signed_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    ip_address: Mapped[Optional[str]] = mapped_column(String(50))
    user_agent: Mapped[Optional[str]] = mapped_column(Text)


# ==================== 短信验证码表 ====================
class SmsCode(Base):
    __tablename__ = "sms_codes"

    id: Mapped[int] = mapped_column(_PK, primary_key=True)
    phone: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(10), nullable=False)
    used: Mapped[bool] = mapped_column(Boolean, default=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


async def init_db():
    """初始化数据库表"""
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

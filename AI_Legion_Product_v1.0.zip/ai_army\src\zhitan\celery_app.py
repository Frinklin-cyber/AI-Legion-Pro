﻿"""Celery 异步任务配置"""
from celery import Celery
from src.zhitan.config import REDIS_URL

celery_app = Celery(
    "zhitan_ai",
    broker=REDIS_URL,
    backend=REDIS_URL,
    broker_connection_retry_on_startup=True,
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Asia/Shanghai",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_routes={
        "src.zhitan.celery_app.run_pipeline": {"queue": "generation"},
    },
)

# 自动发现 tasks 模块中的芹菜任务
celery_app.autodiscover_tasks(["src.zhitan.services"])


@celery_app.task(bind=True, name="src.zhitan.celery_app.run_pipeline")
def run_pipeline(self, task_id: int):
    """运行完整视频生成流水线"""
    from src.zhitan.services.generation_pipeline import GenerationPipeline
    import asyncio

    pipeline = GenerationPipeline(task_id, self.update_state)

    async def _run():
        return await pipeline.execute()

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(_run())
        loop.close()
        return result
    except Exception as e:
        pipeline.mark_failed(str(e))
        raise

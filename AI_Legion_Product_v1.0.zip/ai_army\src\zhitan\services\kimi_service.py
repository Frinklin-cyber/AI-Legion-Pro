﻿"""Kimi API 多模态素材理解服务

Kimi K2.6：看图/看视频抽取卖点（多模态）
Kimi K3：长文本推理/复杂文案（1M 上下文）

角色定位：Kimi 做「眼睛」→ 看素材；DeepSeek 做「笔杆子」→ 写文案
"""

import base64
import json
import os
from typing import Optional

import httpx

from src.zhitan.config import KIMI_API_KEY, KIMI_BASE_URL

# 模型配置（当前 API Key 可用模型：kimi-k2.6, kimi-k2.7-code）
MODEL_DEFAULT = "kimi-k2.6"         # 主力模型：多模态 + 长文本推理
MODEL_MULTIMODAL = "kimi-k2.6"      # 多模态：图/视频理解
MODEL_LONG_TEXT = "kimi-k2.6"       # 长文本推理（无 k3，统一用 k2.6）

# 卖点抽取的 System Prompt
SELLING_POINTS_SYSTEM_PROMPT = """你是一位资深的本地生活探店专家，擅长从商家实拍素材中提取关键卖点。

请仔细分析用户提供的图片/视频素材和文字信息，输出结构化的卖点分析 JSON。

分析维度：
1. 招牌菜品/产品（名称、视觉特征、诱人程度）
2. 环境亮点（装修风格、灯光氛围、空间感受）
3. 目标人群（学生党、上班族、家庭、情侣等）
4. 卖点标签（如：性价比高、出片好看、服务好、排队王、隐藏菜单）
5. 拍摄建议（适合什么镜头语言、色调方向）

输出格式（严格 JSON）：
{
  "store_name": "门店名",
  "category": "品类",
  "highlights": ["卖点1", "卖点2", "卖点3"],
  "signature_items": [{"name": "招牌菜名", "desc": "简短诱人描述", "visual": "视觉特征"}],
  "environment": {"style": "装修风格", "atmosphere": "氛围关键词", "features": ["亮点"]},
  "target_audience": ["人群1", "人群2"],
  "tags": ["#标签1", "#标签2", "#标签3"],
  "shooting_tips": {"tone": "色调方向", "angle": "镜头建议", "pace": "节奏建议"}
}
"""


async def _call_kimi(
    messages: list[dict],
    model: str = MODEL_MULTIMODAL,
    temperature: float = 1.0,
    max_tokens: int = 4000,
    response_format: Optional[dict] = None,
) -> dict:
    """通用 Kimi API 调用（OpenAI 兼容格式）"""
    if not KIMI_API_KEY:
        raise RuntimeError("KIMI_API_KEY 未配置，请在 .env 中设置")

    headers = {
        "Authorization": f"Bearer {KIMI_API_KEY}",
        "Content-Type": "application/json",
    }

    base = KIMI_BASE_URL.rstrip("/")
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    if response_format:
        payload["response_format"] = response_format

    async with httpx.AsyncClient(timeout=120) as client:
        r = await client.post(f"{base}/chat/completions", headers=headers, json=payload)

    if r.status_code != 200:
        err_detail = r.text[:500]
        raise RuntimeError(f"Kimi API 调用失败 [{r.status_code}]: {err_detail}")

    return r.json()


def _image_to_base64(file_path: str) -> str:
    """将本地图片文件转为 base64 data URI"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"图片文件不存在: {file_path}")

    # 自动检测 MIME 类型
    ext = os.path.splitext(file_path)[1].lower()
    mime_map = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".bmp": "image/bmp",
    }
    mime = mime_map.get(ext, "image/png")

    with open(file_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")
    return f"data:{mime};base64,{b64}"


async def analyze_materials(
    material_paths: list[str],
    store_info: dict,
    video_urls: Optional[list[str]] = None,
) -> dict:
    """使用 Kimi K2.6 多模态分析商家素材，提取结构化卖点

    Args:
        material_paths: 本地图片/视频文件路径列表
        store_info: {"name", "category", "address", "description": str}
        video_urls: 视频文件的 HTTP URL（Kimi 支持 video_url 输入类型）

    Returns:
        {"highlights": [...], "signature_items": [...], ...}
    """
    # 构建多模态消息内容
    user_content = [
        {
            "type": "text",
            "text": f"""请分析以下商家的实拍素材，提取结构化的探店卖点。

【商家文字信息】
门店名称：{store_info.get('name', '未命名')}
品类：{store_info.get('category', '美食')}
地址：{store_info.get('address', '')}
补充描述：{store_info.get('description', '')}

请仔细查看素材，输出 JSON 格式的卖点分析。""",
        }
    ]

    # 添加图片素材（base64）
    image_count = 0
    for path in material_paths:
        if not os.path.exists(path):
            continue
        ext = os.path.splitext(path)[1].lower()
        if ext in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"):
            try:
                data_uri = _image_to_base64(path)
                user_content.append({
                    "type": "image_url",
                    "image_url": {"url": data_uri},
                })
                image_count += 1
            except Exception:
                pass

    # 添加视频素材（通过 video_url 引用）
    video_count = 0
    if video_urls:
        for vurl in video_urls[:2]:  # 限制最多 2 个视频
            user_content.append({
                "type": "video_url",
                "video_url": {"url": vurl},
            })
            video_count += 1

    # 至少需要一些内容
    if image_count == 0 and video_count == 0:
        # 没有素材，仅用文字分析
        user_content[0]["text"] += "\n\n（注意：没有上传实拍素材，请根据文字描述推断卖点）"

    messages = [
        {"role": "system", "content": SELLING_POINTS_SYSTEM_PROMPT},
        {"role": "user", "content": user_content},
    ]

    response = await _call_kimi(
        messages=messages,
        model=MODEL_MULTIMODAL,
        temperature=1.0,
        max_tokens=4000,
        response_format={"type": "json_object"},
    )

    content = response["choices"][0]["message"]["content"].strip()
    # 清理可能的 markdown 代码块
    if content.startswith("```json"):
        content = content[7:]
    if content.startswith("```"):
        content = content[3:]
    if content.endswith("```"):
        content = content[:-3]
    content = content.strip()

    try:
        result = json.loads(content)
    except json.JSONDecodeError:
        raise RuntimeError(f"Kimi 返回非合法 JSON:\n{content[:500]}")

    # 补充元信息
    result["_analyzed_by"] = "kimi-k2.6"
    result["_material_count"] = {"images": image_count, "videos": video_count}

    return result


async def extract_selling_points_text_only(store_info: dict) -> dict:
    """纯文本卖点抽取（无素材时的降级方案）- 使用 Kimi K2.6

    Args:
        store_info: {"name", "category", "address", "description": str, tags: [...str]}

    Returns:
        同 analyze_materials 的 JSON 格式
    """
    desc_text = store_info.get("description", "")
    tags_text = ", ".join(store_info.get("tags", []))

    user_text = f"""请根据以下门店文字信息，推断并生成探店卖点分析：

门店名称：{store_info.get('name', '未命名')}
品类：{store_info.get('category', '美食')}
地址：{store_info.get('address', '')}
描述：{desc_text}
标签：{tags_text}

请基于行业经验和你对{store_info.get('category', '美食')}品类的理解，输出结构化的卖点分析 JSON。"""

    messages = [
        {"role": "system", "content": SELLING_POINTS_SYSTEM_PROMPT},
        {"role": "user", "content": user_text},
    ]

    response = await _call_kimi(
        messages=messages,
        model=MODEL_LONG_TEXT,
        temperature=1.0,
        max_tokens=4000,
        response_format={"type": "json_object"},
    )

    content = response["choices"][0]["message"]["content"].strip()
    if content.startswith("```json"):
        content = content[7:]
    if content.startswith("```"):
        content = content[3:]
    if content.endswith("```"):
        content = content[:-3]
    content = content.strip()

    try:
        result = json.loads(content)
    except json.JSONDecodeError:
        raise RuntimeError(f"Kimi 返回非合法 JSON:\n{content[:500]}")

    result["_analyzed_by"] = "kimi-k2.6-text-only"
    result["_material_count"] = {"images": 0, "videos": 0}
    return result


async def enhance_storyboard_context(
    selling_points: dict,
    store_info: dict,
) -> str:
    """用 Kimi K3 将卖点增强为 DeepSeek 友好的创作上下文

    将结构化卖点转化为自然语言描述，作为 DeepSeek 分镜生成的补充物料。
    """
    sp_json = json.dumps(selling_points, ensure_ascii=False, indent=2)

    user_text = f"""请根据以下商家的卖点分析数据，生成一段自然流畅的「创作素材摘要」，供视频脚本师使用。

门店信息：
- 名称：{store_info.get('name', '未知')}
- 品类：{store_info.get('category', '美食')}

卖点分析 JSON：
{sp_json}

要求：
1. 用口语化、有网感的语言概括核心卖点
2. 突出 3 个最吸引人的高亮卖点
3. 给出 2-3 个适合抖音探店的画面创意提示
4. 控制在 300 字以内"""

    messages = [
        {
            "role": "system",
            "content": "你是一个探店短视频的内容策划，擅长将门店卖点转化为有吸引力的创作素材。",
        },
        {"role": "user", "content": user_text},
    ]

    response = await _call_kimi(
        messages=messages,
        model=MODEL_LONG_TEXT,
        temperature=1.0,
        max_tokens=800,
    )

    return response["choices"][0]["message"]["content"].strip()

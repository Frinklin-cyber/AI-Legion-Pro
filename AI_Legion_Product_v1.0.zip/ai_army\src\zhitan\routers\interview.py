﻿"""AI 采访式剧本生成 - 通过问答引导商家输入 → 生成完整分镜脚本"""

import json
import logging
import random
import uuid
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from src.zhitan.config import DEEPSEEK_API_KEY, DEEPSEEK_BASE_URL
from src.zhitan.routers.auth import get_current_merchant

logger = logging.getLogger(__name__)
router = APIRouter()

# 会话存储（生产环境应换 Redis）
_interview_sessions: dict[str, dict] = {}

# 采访问题模板池（每轮随机抽取，保证基本覆盖面）
QUESTION_POOL = [
    {
        "id": "type",
        "question": "您这家店主要做什么生意呢？比如火锅、烧烤、咖啡、美发、还是其他？简单介绍下品类。",
        "hint": "品类+特色（如：重庆老火锅，主打鲜毛肚）",
        "key": "店类型/品类",
    },
    {
        "id": "hero",
        "question": "店里最拿手、顾客必点的招牌菜/明星服务是什么？描述一两样让他们非来不可的理由。",
        "hint": "招牌必点 + 卖点",
        "key": "招牌产品",
    },
    {
        "id": "env",
        "question": "店里的环境风格怎么样？有没有特别适合拍照打卡的角落？",
        "hint": "环境风格（如：ins风/国潮/极简）、打卡点",
        "key": "环境氛围",
    },
    {
        "id": "price",
        "question": "人均消费大概在什么范围？最近有什么优惠活动吗？",
        "hint": "人均价格、活动折扣",
        "key": "价格/活动",
    },
    {
        "id": "address",
        "question": "门店具体在哪？周围有没有大家熟悉的地标？",
        "hint": "地址+附近地标",
        "key": "地址位置",
    },
    {
        "id": "audience",
        "question": "主要来消费的是哪些人群？情侣约会、家庭聚餐、还是年轻打卡族？",
        "hint": "目标客群",
        "key": "受众客群",
    },
    {
        "id": "hour",
        "question": "营业时间是？哪个时段最热闹？",
        "hint": "营业时间 + 高峰时段",
        "key": "营业时间",
    },
    {
        "id": "story",
        "question": "开店背后有没有有趣的故事或让人印象深刻的初心？",
        "hint": "创始故事/情怀",
        "key": "品牌故事",
    },
]

# 探针开场白
WELCOME_QUESTION = {
    "id": "start",
    "question": "您好！我是您的专属探店编剧 AI 🎬，接下来我会问您几个简单问题，帮您量身定制一条爆款探店视频。准备好了吗？\n\n首先：您这家店叫什么名字？做什么生意的？",
    "hint": "店名 + 品类（如：巴适老火锅，正宗重庆味）",
    "key": "店名+品类",
}

# 衔接语
BRIDGE_QUESTIONS = [
    "了解！继续～",
    "太棒了，那再问一个：",
    "收到，下一个问题是：",
    "不错不错，再聊聊这个：",
]


def _select_questions() -> list[dict]:
    """精选 4-5 个核心问题"""
    # 核心问题 ID 列表
    core = ["hero", "env", "price", "audience", "address"]
    selected = [q for q in QUESTION_POOL if q["id"] in core]
    random.shuffle(selected)
    return selected[:4]


async def _ask_deepseek(prompt: str, system_prompt: str = None) -> str:
    """调用 DeepSeek 完成一次对话"""
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})

    async with httpx.AsyncClient(timeout=90) as client:
        rsp = await client.post(
            f"{DEEPSEEK_BASE_URL}/chat/completions",
            headers={
                "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": "deepseek-chat",
                "messages": messages,
                "temperature": 0.8,
                "max_tokens": 2048,
            },
        )
        if rsp.status_code != 200:
            logger.error(f"DeepSeek 调用失败: {rsp.status_code} {rsp.text[:300]}")
            raise HTTPException(502, "AI 服务暂时不可用，请稍后重试")
        data = rsp.json()
        return data["choices"][0]["message"]["content"].strip()


async def _generate_storyboard(answers: dict) -> dict:
    """基于采访回答，生成完整分镜剧本"""
    qa_text = ""
    for i, (question, answer) in enumerate(answers.items(), 1):
        qa_text += f"Q{i}: {question}\nA{i}: {answer}\n\n"

    prompt = f"""你是资深探店短视频编剧。以下是对一家门店的采访记录，请据此生成一份 4-6 镜的探店分镜脚本。

==采访记录==
{qa_text}
==要求==
1. 每镜包含：scene_no（从1开始）、narration（口播文案，15-40字）、subtitle（画面上屏字幕，10-16字）、duration（秒数，4-8）
2. 全片总时长控制在 30-45 秒内
3. 开篇 1 秒抓眼球，结尾 1 镜引导互动（关注/收藏/打卡）
4. 文案节奏快、口语化、有情绪起伏
5. 不要提价格（除非采访明确提到了优惠）
6. 埋一个「互动钩子」（如：你最想带谁来吃？评论区@ta）

请只输出 JSON，格式如下：
```json
{{
  "title": "视频标题（10字以内）",
  "scenes": [
    {{
      "scene_no": 1,
      "narration": "口播文案",
      "subtitle": "画面上屏字幕",
      "duration": 6
    }}
  ]
}}
```"""

    raw = await _ask_deepseek(prompt)
    # 提取 JSON
    json_start = raw.find("{")
    json_end = raw.rfind("}") + 1
    if json_start == -1 or json_end <= json_start:
        logger.warning(f"DeepSeek 未返回有效 JSON，使用原始文本: {raw[:300]}")
        raise HTTPException(500, "剧本生成格式异常，请重试")

    try:
        return json.loads(raw[json_start:json_end])
    except json.JSONDecodeError:
        # 尝试修复常见 JSON 问题
        cleaned = raw[json_start:json_end]
        # 去除尾部逗号
        cleaned = cleaned.replace(",}", "}").replace(",\n}", "\n}")
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            logger.warning(f"JSON 解析失败: {raw[:500]}")
            raise HTTPException(500, "剧本解析失败，请重试")


# ==================== API 端点 ====================

class InterviewStartReq(BaseModel):
    store_name: str  # 门店名称
    store_category: Optional[str] = ""  # 品类（可选）


class InterviewStartResp(BaseModel):
    session_id: str
    question_id: str
    question: str
    hint: str
    key: str
    progress: str  # "0/5"
    title: str  # 开场标题


class InterviewAnswerReq(BaseModel):
    session_id: str
    answer: str


class InterviewAnswerResp(BaseModel):
    done: bool  # 是否采访完成
    question_id: str  # 当前问题ID（未完成时）
    question: str  # 下一问题（未完成时）/ 完成提示（完成时）
    hint: str
    key: str
    progress: str  # "3/5"
    storyboard: Optional[dict] = None  # 完成时返回剧本


@router.post("/start", response_model=InterviewStartResp)
async def start_interview(
    body: InterviewStartReq,
    merchant: dict = Depends(get_current_merchant),
):
    """开始 AI 采访 - 基于门店信息生成定制化提问"""

    store_name = body.store_name.strip()
    if not store_name:
        raise HTTPException(400, "请填写门店名称")

    session_id = uuid.uuid4().hex

    # 选择问题队列
    questions = _select_questions()
    total = 1 + len(questions)  # 开场 + 核心问题

    session = {
        "store_name": store_name,
        "store_category": body.store_category or "",
        "questions": questions,
        "current_idx": -1,  # -1 表示还未开始
        "answers": [],
        "total": total,
        "current_q_id": "start",  # 当前已发送问题的 ID
        "has_generated": False,  # 防重复生成
    }
    _interview_sessions[session_id] = session

    return InterviewStartResp(
        session_id=session_id,
        question_id=WELCOME_QUESTION["id"],
        question=f"好的，我们来为「{store_name}」量身打造探店剧本！\n\n{WELCOME_QUESTION['question']}",
        hint=WELCOME_QUESTION["hint"],
        key=WELCOME_QUESTION["key"],
        progress=f"0/{total}",
        title=f"「{store_name}」探店采访",
    )


@router.post("/answer", response_model=InterviewAnswerResp)
async def answer_question(
    body: InterviewAnswerReq,
    merchant: dict = Depends(get_current_merchant),
):
    """回答一个问题，获取下一个问题或最终剧本"""

    session = _interview_sessions.get(body.session_id)
    if not session:
        raise HTTPException(404, "会话过期或不存在，请重新开始")

    if session.get("has_generated"):
        raise HTTPException(400, "本轮采访已完成，请重新开始")

    answer_text = body.answer.strip()
    if not answer_text:
        raise HTTPException(400, "请输入回答（至少 2 个字）")

    # 记录本轮回答
    session["answers"].append({
        "q_id": session["current_q_id"],
        "question": session.get("_last_question", ""),
        "answer": answer_text,
    })
    session["current_idx"] += 1
    current_idx = session["current_idx"]

    total = session["total"]
    questions = session["questions"]

    # 判断是否完成
    if current_idx >= len(questions):
        # === 采访完成 → 生成剧本 ===
        session["has_generated"] = True

        # 构建 Q&A 映射
        qa_map = {}
        for item in session["answers"]:
            qa_map[item["question"]] = item["answer"]

        try:
            storyboard = await _generate_storyboard(qa_map)
        except Exception as e:
            session["has_generated"] = False
            raise e

        return InterviewAnswerResp(
            done=True,
            question_id="finish",
            question="采访完成！已为您生成了专属探店剧本 🎉",
            hint="请查看下方生成的剧本",
            key="完成",
            progress=f"{total}/{total}",
            storyboard=storyboard,
        )

    else:
        # === 继续提问 ===
        next_q = questions[current_idx]
        bridge = random.choice(BRIDGE_QUESTIONS)
        session["current_q_id"] = next_q["id"]
        session["_last_question"] = next_q["question"]

        return InterviewAnswerResp(
            done=False,
            question_id=next_q["id"],
            question=f"{bridge}\n\n{next_q['question']}",
            hint=next_q["hint"],
            key=next_q["key"],
            progress=f"{current_idx + 1}/{total}",
            storyboard=None,
        )


class DetectCategoryReq(BaseModel):
    store_name: str


class DetectCategoryResp(BaseModel):
    category: str


@router.post("/detect_category", response_model=DetectCategoryResp)
async def detect_category(
    body: DetectCategoryReq,
    merchant: dict = Depends(get_current_merchant),
):
    """根据门店名称自动识别品类"""
    store_name = body.store_name.strip()
    if not store_name:
        raise HTTPException(400, "请填写门店名称")

    prompt = f"""请根据以下门店名称，判断它属于什么品类（行业类别）。
只输出品类名称本身，不要有任何解释、标点或多余文字。

门店名称：{store_name}

示例输出：
- 重庆火锅
- 精品咖啡
- 日式烤肉
- 民宿
- 美发沙龙
- 宠物美容
- 密室逃脱

品类："""

    try:
        raw = await _ask_deepseek(prompt, system_prompt="你是一个本地生活行业分类专家，只输出品类名称，不输出任何其他内容。")
        category = raw.strip().strip("-").strip("*").strip("·").strip()
        # 去除常见前缀
        for prefix in ["品类：", "类别：", "行业：", "分类："]:
            if category.startswith(prefix):
                category = category[len(prefix):].strip()
        if not category:
            category = "其他"
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"品类识别失败: {e}")
        raise HTTPException(502, "AI 服务暂时不可用，请稍后重试")

    return DetectCategoryResp(category=category)


@router.post("/reset")
async def reset_interview(
    body: InterviewStartReq,
    merchant: dict = Depends(get_current_merchant),
):
    """重新开始采访"""
    return await start_interview(body, merchant)

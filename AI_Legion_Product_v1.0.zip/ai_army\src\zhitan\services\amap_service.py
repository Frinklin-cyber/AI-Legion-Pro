﻿"""高德地图后端服务 - 周边搜索"""
import httpx
from typing import Optional
from loguru import logger
from src.zhitan.config import AMAP_WEB_KEY


class AmapService:
    """高德地图 Web 服务"""

    @staticmethod
    async def get_pois_around(
        lng: float,
        lat: float,
        radius: int = 500,
        types: Optional[str] = None,
        keywords: Optional[str] = None,
    ) -> list[dict]:
        """获取周边POI"""
        if not AMAP_WEB_KEY:
            logger.warning("高德Web服务Key未配置")
            return []

        url = "https://restapi.amap.com/v5/place/around"
        params = {
            "key": AMAP_WEB_KEY,
            "location": f"{lng},{lat}",
            "radius": radius,
            "sortrule": "distance",
            "page_size": 20,
            "output": "json",
        }
        if keywords:
            params["keywords"] = keywords
        if types:
            params["types"] = types

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                r = await client.get(url, params=params)
                data = r.json()
            if data.get("status") != "1":
                return []
            return data.get("pois", {}).get("poi", [])
        except Exception as e:
            logger.error(f"高德周边搜索失败: {e}")
            return []

    @staticmethod
    def format_pois_for_ai(pois: list[dict]) -> str:
        """将POI列表格式化为AI可用的上下文文本"""
        if not pois:
            return "周边无特别地标"
        lines = ["门店周边环境概况："]
        for i, poi in enumerate(pois[:10], 1):
            name = poi.get("name", "")
            ptype = poi.get("type", "")
            dist = poi.get("distance", "")
            lines.append(f"{i}. {name}（{ptype}，距门店约{int(dist)}米）")
        return "\n".join(lines)


amap_service = AmapService()

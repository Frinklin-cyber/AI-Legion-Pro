﻿"""环境配置 - 支持.env文件和默认值"""
import os
from dotenv import load_dotenv

load_dotenv()

# ---- 数据库 (默认 SQLite，生产环境用 PostgreSQL) ----
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./zhitan_ai.db")
SYNC_DATABASE_URL = os.getenv("SYNC_DATABASE_URL", "sqlite:///./zhitan_ai.db")

# ---- Redis ----
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

# ---- JWT ----
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "zhitan-ai-jwt-secret-change-in-production")
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_DAYS = 7

# ---- 短信（模拟） ----
SMS_PROVIDER = os.getenv("SMS_PROVIDER", "mock")

# ---- 腾讯云 COS ----
COS_SECRET_ID = os.getenv("COS_SECRET_ID", "")
COS_SECRET_KEY = os.getenv("COS_SECRET_KEY", "")
COS_BUCKET = os.getenv("COS_BUCKET", "zhitan-ai-1250000000")
COS_REGION = os.getenv("COS_REGION", "ap-guangzhou")
COS_MATERIAL_PREFIX = "materials/"
COS_VIDEO_PREFIX = "videos/"

# ---- Coze 工作流 ----
COZE_WORKFLOW_URL = os.getenv("COZE_WORKFLOW_URL", "")
COZE_API_TOKEN = os.getenv("COZE_API_TOKEN", "")

# ---- DeepSeek API ----
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
DEEPSEEK_BASE_URL = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1")

# ---- 即梦 API（火山引擎 AK/SK） ----
JIMENG_ACCESS_KEY_ID = os.getenv("JIMENG_ACCESS_KEY_ID", "")
JIMENG_SECRET_ACCESS_KEY = os.getenv("JIMENG_SECRET_ACCESS_KEY", "")
JIMENG_REGION = os.getenv("JIMENG_REGION", "cn-north-1")
JIMENG_SERVICE = os.getenv("JIMENG_SERVICE", "cv")

# ---- Kimi API ----
KIMI_API_KEY = os.getenv("KIMI_API_KEY", "")
KIMI_BASE_URL = os.getenv("KIMI_BASE_URL", "https://api.moonshot.cn/v1")

# ---- TTS ----
TTS_PROVIDER = os.getenv("TTS_PROVIDER", "volcano_ark")  # volcano_ark | edge_tts
TTS_APP_ID = os.getenv("TTS_APP_ID", "")
TTS_ACCESS_TOKEN = os.getenv("TTS_ACCESS_TOKEN", "")
TTS_DEFAULT_VOICE = os.getenv("TTS_DEFAULT_VOICE", "zh_female_qingxin")
TTS_DEFAULT_SPEED = float(os.getenv("TTS_DEFAULT_SPEED", "1.15"))
# 火山方舟 Ark TTS API Key（在 https://console.volcengine.com/ark 创建）
# 不配置则自动使用 Edge-TTS 降级方案
ARK_API_KEY = os.getenv("ARK_API_KEY", "")
ARK_TTS_ENDPOINT = os.getenv("ARK_TTS_ENDPOINT", "https://ark.cn-beijing.volces.com/api/v3/audio/speech")

# ---- 微信支付 ----
WECHAT_PAY_APP_ID = os.getenv("WECHAT_PAY_APP_ID", "")
WECHAT_PAY_MCH_ID = os.getenv("WECHAT_PAY_MCH_ID", "")
WECHAT_PAY_API_V3_KEY = os.getenv("WECHAT_PAY_API_V3_KEY", "")
WECHAT_PAY_SERIAL_NO = os.getenv("WECHAT_PAY_SERIAL_NO", "")
WECHAT_PAY_PRIVATE_KEY_PATH = os.getenv("WECHAT_PAY_PRIVATE_KEY_PATH", "")
WECHAT_PAY_NOTIFY_URL = os.getenv("WECHAT_PAY_NOTIFY_URL", "")

# ---- 高德地图 ----
AMAP_WEB_KEY = os.getenv("AMAP_WEB_KEY", "")       # Web服务Key（后端用）
AMAP_JS_KEY = os.getenv("AMAP_JS_KEY", "")          # JS API Key（前端用）
AMAP_JS_SECRET = os.getenv("AMAP_JS_SECRET", "")    # JS API 安全密钥

# ---- FFmpeg（优先系统安装，否则用 imageio-ffmpeg） ----
def _ffmpeg_path():
    p = os.getenv("FFMPEG_PATH", "ffmpeg")
    if not os.path.exists(p) and p == "ffmpeg":
        try:
            from imageio_ffmpeg import get_ffmpeg_exe
            p = get_ffmpeg_exe()
        except Exception:
            pass
    return p

FFMPEG_PATH = _ffmpeg_path()
FFPROBE_PATH = os.getenv("FFPROBE_PATH", FFMPEG_PATH)  # 默认复用 ffmpeg 做探测

# ---- 上传限制 ----
# 最大上传文件大小（MB）：默认 500MB 支持 4K 视频
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "500"))
# 大文件分块大小（字节），200MB+ 的文件走流式写入
CHUNK_SIZE = 8 * 1024 * 1024  # 8MB per chunk

# ---- 服务 ----
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))

﻿"""AI 配音服务 - 火山方舟 TTS + 多音色 + 语速控制

支持多种 TTS 后端：
  1. 火山方舟 Ark TTS（通过 API Key，音质最佳）
  2. Edge-TTS（免费，始终可用的降级方案）

探店推荐音色：
  - 知性女声（zh_female_qingxin / 晓伊）→ 适合美妆、生活方式探店
  - 自然男声（zh_male_wennuan / 晓辰）→ 适合美食、硬核探店
  - 爽快女声（zh_female_shuangkuai / 晓晓）→ 适合年轻化、快节奏
"""

import asyncio
import hashlib
import hmac
import json
import logging
import os
import tempfile
import time
import uuid
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import quote

import httpx

from src.zhitan.config import (
    JIMENG_ACCESS_KEY_ID,
    JIMENG_SECRET_ACCESS_KEY,
)

logger = logging.getLogger(__name__)

# ============================================================
# 音色配置
# ============================================================

VOICE_PROFILES = {
    # ---- 火山方舟 Ark TTS 音色 ----
    "zh_female_qingxin": {
        "name": "知性女声-晓伊",
        "gender": "female",
        "style": "知性、温柔、有亲和力",
        "recommend": "美妆、生活方式、精致探店",
    },
    "zh_female_shuangkuai": {
        "name": "爽快女声-晓晓",
        "gender": "female",
        "style": "活泼、快节奏、年轻化",
        "recommend": "年轻化探店、快餐、潮流",
    },
    "zh_male_wennuan": {
        "name": "自然男声-晓辰",
        "gender": "male",
        "style": "温暖、自然、有磁性",
        "recommend": "美食探店、火锅烧烤",
    },
    "zh_female_tianmei": {
        "name": "甜美女声",
        "gender": "female",
        "style": "甜美、可爱、元气",
        "recommend": "甜品、奶茶、少女风探店",
    },
    "zh_male_chengshu": {
        "name": "成熟男声",
        "gender": "male",
        "style": "沉稳、大气、专业感",
        "recommend": "高端餐饮、星级探店",
    },
    "zh_female_wenjing": {
        "name": "文静女声",
        "gender": "female",
        "style": "文静、优雅、娓娓道来",
        "recommend": "书吧、茶馆、文艺探店",
    },
    # ---- Edge-TTS 降级音色 ----
    "edge_zh-CN-XiaoyiNeural": {
        "name": "晓伊 (Edge)",
        "gender": "female",
        "style": "温柔清晰",
        "provider": "edge-tts",
    },
    "edge_zh-CN-YunxiNeural": {
        "name": "云希 (Edge)",
        "gender": "male",
        "style": "自然磁性",
        "provider": "edge-tts",
    },
    "edge_zh-CN-XiaoxiaoNeural": {
        "name": "晓晓 (Edge)",
        "gender": "female",
        "style": "活泼清晰",
        "provider": "edge-tts",
    },
}

# 探店默认推荐音色
RECOMMENDED_VOICES = [
    "zh_female_qingxin",
    "zh_male_wennuan",
    "zh_female_shuangkuai",
    "zh_female_tianmei",
]

# ============================================================
# 火山方舟 Ark TTS（API Key 模式）
# ============================================================

ARK_TTS_ENDPOINT = os.getenv(
    "ARK_TTS_ENDPOINT",
    "https://ark.cn-beijing.volces.com/api/v3/audio/speech",
)
ARK_API_KEY = os.getenv("ARK_API_KEY", "")

# 如果用户有 AK/SK 但没有 ARK_API_KEY，可以使用 AK/SK 签名方式请求 Ark
# Ark 也支持 AK/SK 的 Signature V4 签名
ARK_HOST = "ark.cn-beijing.volces.com"
ARK_TTS_PATH = "/api/v3/audio/speech"


def _sign_ark_tts(method: str, path: str, body_str: str) -> dict:
    """为 Ark TTS 生成 AK/SK Signature V4 签名（与即梦同源）"""
    if not JIMENG_ACCESS_KEY_ID or not JIMENG_SECRET_ACCESS_KEY:
        raise RuntimeError("火山引擎 AK/SK 未配置")

    now = datetime.now(timezone.utc)
    x_date = now.strftime("%Y%m%dT%H%M%SZ")
    date_short = now.strftime("%Y%m%d")
    region = "cn-beijing"
    service = "ark"

    # Canonical Request
    content_type = "application/json"
    payload_hash = hashlib.sha256(body_str.encode("utf-8")).hexdigest()
    canonical_uri = quote(path, safe="/")
    canonical_headers = (
        f"content-type:{content_type}\n"
        f"host:{ARK_HOST}\n"
        f"x-date:{x_date}\n"
    )
    signed_headers = "content-type;host;x-date"
    canonical_request = (
        f"{method}\n"
        f"{canonical_uri}\n"
        f"\n"
        f"{canonical_headers}\n"
        f"{signed_headers}\n"
        f"{payload_hash}"
    )

    algorithm = "HMAC-SHA256"
    credential_scope = f"{date_short}/{region}/{service}/request"
    string_to_sign = (
        f"{algorithm}\n"
        f"{x_date}\n"
        f"{credential_scope}\n"
        f"{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"
    )

    sk = JIMENG_SECRET_ACCESS_KEY.encode("utf-8")
    k_date = hmac.new(sk, date_short.encode("utf-8"), hashlib.sha256).digest()
    k_region = hmac.new(k_date, region.encode("utf-8"), hashlib.sha256).digest()
    k_service = hmac.new(k_region, service.encode("utf-8"), hashlib.sha256).digest()
    k_signing = hmac.new(k_service, b"request", hashlib.sha256).digest()
    signature = hmac.new(k_signing, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

    authorization = (
        f"{algorithm} Credential={JIMENG_ACCESS_KEY_ID}/{credential_scope}, "
        f"SignedHeaders={signed_headers}, Signature={signature}"
    )

    return {
        "Authorization": authorization,
        "Content-Type": content_type,
        "Host": ARK_HOST,
        "X-Date": x_date,
    }


async def _ark_tts_generate(
    text: str,
    voice: str = "zh_female_qingxin",
    speed: float = 1.15,
    response_format: str = "mp3",
) -> bytes:
    """调用火山方舟 Ark TTS 语音合成

    优先使用 ARK_API_KEY（Bearer Token），否则使用 AK/SK 签名。
    模型：doubao-seed-tts-2.0（豆包语音合成2.0）
    """
    payload = {
        "model": "doubao-seed-tts-2.0",
        "input": text,
        "voice": voice,
        "response_format": response_format,
        "speed": speed,
    }
    body_str = json.dumps(payload, ensure_ascii=False)

    if ARK_API_KEY:
        headers = {
            "Authorization": f"Bearer {ARK_API_KEY}",
            "Content-Type": "application/json",
        }
    else:
        headers = _sign_ark_tts("POST", ARK_TTS_PATH, body_str)

    url = ARK_TTS_ENDPOINT if ARK_API_KEY else f"https://{ARK_HOST}{ARK_TTS_PATH}"

    async with httpx.AsyncClient(timeout=120) as client:
        r = await client.post(url, headers=headers, content=body_str)

    if r.status_code == 200:
        return r.content
    else:
        detail = r.text[:500]
        raise RuntimeError(f"Ark TTS 调用失败 [{r.status_code}]: {detail}")


async def _edge_tts_generate(
    text: str,
    voice: str = "zh-CN-XiaoyiNeural",
    speed: float = 1.15,
    output_path: str = "",
) -> str:
    """Edge-TTS 语音合成（免费降级方案）"""
    try:
        import edge_tts
    except ImportError:
        raise RuntimeError("edge-tts 未安装，请执行: pip install edge-tts")

    if not output_path:
        output_path = os.path.join(tempfile.gettempdir(), f"tts_{uuid.uuid4().hex[:8]}.mp3")

    # edge-tts 语速格式: "+15%" 表示 1.15 倍
    rate_pct = int((speed - 1.0) * 100)
    rate_str = f"+{rate_pct}%" if rate_pct >= 0 else f"{rate_pct}%"

    communicate = edge_tts.Communicate(text, voice, rate=rate_str)
    await communicate.save(output_path)

    return output_path


# ============================================================
# 主接口
# ============================================================

async def generate_speech(
    text: str,
    voice: str = "zh_female_qingxin",
    speed: float = 1.15,
    output_path: str = "",
    output_format: str = "mp3",
) -> str:
    """语音合成主入口

    优先尝试 Ark TTS（音质最佳），失败则降级到 Edge-TTS。

    Args:
        text: 合成文本
        voice: 音色 ID（见 VOICE_PROFILES）
        speed: 语速倍率（1.0 = 原速，推荐 1.1-1.2 更适合短视频）
        output_path: 输出文件路径（默认自动生成临时路径）
        output_format: 输出格式 mp3/wav

    Returns:
        音频文件绝对路径
    """
    if not output_path:
        output_path = os.path.join(tempfile.gettempdir(), f"tts_{uuid.uuid4().hex[:8]}.{output_format}")

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    # 尝试 Ark TTS
    if voice in VOICE_PROFILES and VOICE_PROFILES[voice].get("provider") != "edge-tts":
        try:
            audio_bytes = await _ark_tts_generate(
                text=text,
                voice=voice,
                speed=speed,
                response_format=output_format,
            )
            with open(output_path, "wb") as f:
                f.write(audio_bytes)
            logger.info(f"Ark TTS 生成完成: {output_path} ({len(audio_bytes)} bytes)")
            return output_path
        except Exception as e:
            logger.warning(f"Ark TTS 失败，降级到 Edge-TTS: {e}")

    # 降级到 Edge-TTS
    edge_voice = _pick_edge_voice(voice)
    try:
        result = await _edge_tts_generate(
            text=text,
            voice=edge_voice,
            speed=speed,
            output_path=output_path,
        )
        logger.info(f"Edge-TTS 生成完成: {result}")
        return result
    except Exception as e:
        raise RuntimeError(f"所有 TTS 后端均失败: {e}")


async def generate_scene_audios(
    scenes: list[dict],
    voice: str = "zh_female_qingxin",
    speed: float = 1.15,
    output_dir: str = "",
) -> list[dict]:
    """批量生成分镜配音

    Args:
        scenes: 分镜列表 [{"scene_no": 1, "narration": "...", "duration": 5}, ...]
        voice: 音色
        speed: 语速
        output_dir: 输出目录

    Returns:
        更新后的分镜列表，增加 audio_path 字段
    """
    if not output_dir:
        output_dir = os.path.join(tempfile.gettempdir(), f"tts_scenes_{uuid.uuid4().hex[:8]}")
    os.makedirs(output_dir, exist_ok=True)

    results = []
    for scene in scenes:
        narration = scene.get("narration", "").strip()
        if not narration:
            scene["audio_path"] = ""
            results.append(scene)
            continue

        filename = f"scene_{scene.get('scene_no', 0):02d}.mp3"
        filepath = os.path.join(output_dir, filename)

        try:
            path = await generate_speech(
                text=narration,
                voice=voice,
                speed=speed,
                output_path=filepath,
            )
            scene["audio_path"] = path
            # 估算音频时长（中文约 4 字/秒 × 语速倍率）
            est_duration = len(narration) / (4.0 * speed)
            scene["audio_duration"] = est_duration
        except Exception as e:
            logger.error(f"场景 {scene.get('scene_no')} TTS 失败: {e}")
            scene["audio_path"] = ""
            scene["audio_duration"] = scene.get("duration", 5)

        results.append(scene)

    return results


def _pick_edge_voice(voice: str) -> str:
    """根据目标音色选择最接近的 Edge-TTS 音色"""
    female_voices = [
        "zh-CN-XiaoyiNeural",  # 晓伊 - 温柔
        "zh-CN-XiaoxiaoNeural",  # 晓晓 - 活泼
    ]
    male_voices = [
        "zh-CN-YunxiNeural",  # 云希 - 自然男声
        "zh-CN-YunyangNeural",  # 云扬 - 新闻男声
    ]

    if voice in VOICE_PROFILES:
        gender = VOICE_PROFILES[voice].get("gender", "female")
        if "shuangkuai" in voice or "tianmei" in voice:
            return female_voices[1]  # 活泼类 → 晓晓
        elif "chengshu" in voice or "wenjing" in voice:
            return female_voices[0]  # 文静类 → 晓伊
        elif gender == "male":
            return male_voices[0]  # 男声 → 云希
        else:
            return female_voices[0]  # 默认女声 → 晓伊

    # 直接匹配 edge 音色
    edge_name = voice.replace("edge_", "")
    if edge_name.startswith("zh-CN-"):
        return edge_name
    return "zh-CN-XiaoyiNeural"


async def list_available_voices() -> list[dict]:
    """列出所有可用音色（含推荐标记）"""
    result = []
    for vid, profile in VOICE_PROFILES.items():
        entry = {"id": vid, **profile}
        if vid in RECOMMENDED_VOICES:
            entry["recommended"] = True
        result.append(entry)
    return result
